<?php $__env->startSection('title','Manajemen User'); ?>
<?php $__env->startSection('page-title','Manajemen User'); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header p-3 d-flex justify-content-between align-items-center">
        <div><i class="bi bi-person-gear text-primary me-2"></i>Daftar User</div>
        <a href="<?php echo e(route('users.create')); ?>" class="btn btn-sm btn-primary">
            <i class="bi bi-plus-lg me-1"></i>Tambah User
        </a>
    </div>
    <div class="table-responsive">
        <table class="table user-table mb-0">
            <thead class="table-light">
                <tr>
                    <th class="ps-3">#</th><th>Nama</th><th>Email</th><th>Role</th>
                    <th>Terdaftar</th><th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td class="ps-3 text-muted"><?php echo e($users->firstItem() + $i); ?></td>
                    <td class="fw-semibold">
                        <?php echo e($u->name); ?>

                        <?php if($u->id === auth()->id()): ?>
                        <span class="badge bg-success ms-1">Anda</span>
                        <?php endif; ?>
                    </td>
                    <td><?php echo e($u->email); ?></td>
                    <td>
                        <?php $__currentLoopData = $u->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <span class="badge <?php echo e($role->name=='super_admin' ? 'bg-danger' : ($role->name=='admin' ? 'bg-primary' : 'bg-secondary')); ?>">
                            <?php echo e(ucfirst(str_replace('_',' ',$role->name))); ?>

                        </span>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                    <td class="text-muted small"><?php echo e($u->created_at->format('d M Y')); ?></td>
                    <td>
                        <div class="d-flex gap-1">
                            <a href="<?php echo e(route('users.edit',$u)); ?>" class="btn btn-xs btn-outline-warning">
                                <i class="bi bi-pencil"></i>
                            </a>
                            <?php if($u->id !== auth()->id()): ?>
                            <form method="POST" action="<?php echo e(route('users.destroy',$u)); ?>"
                                  onsubmit="return confirm('Hapus user <?php echo e($u->name); ?>?')">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                <button class="btn btn-xs btn-outline-danger"><i class="bi bi-trash"></i></button>
                            </form>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="6" class="text-center text-muted py-4">Belum ada user</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php if($users->hasPages()): ?>
    <div class="card-footer"><?php echo e($users->links()); ?></div>
    <?php endif; ?>
</div>
<?php $__env->startPush('styles'); ?>
<style>
    .btn-xs { padding: 3px 8px; font-size: .75rem; }
    .user-table td { word-break: break-word; }
    .user-table .badge { white-space: nowrap; }
</style>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\dev\optik-master\resources\views/admin/users/index.blade.php ENDPATH**/ ?>