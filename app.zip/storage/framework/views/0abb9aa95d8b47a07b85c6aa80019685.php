<?php $__env->startSection('title', 'Kategori'); ?>
<?php $__env->startSection('page-title', 'Manajemen Kategori'); ?>

<?php $__env->startSection('content'); ?>
<div class="row g-3">
    
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('category.create')): ?>
    <div class="col-md-4">
        <div class="card p-3">
            <div class="card-header px-0 pt-0 pb-3 mb-3">
                <i class="bi bi-plus-circle text-primary me-2"></i>Tambah Kategori
            </div>
            <form method="POST" action="<?php echo e(route('categories.store')); ?>">
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                    <label class="form-label fw-semibold">Nama Kategori <span class="text-danger">*</span></label>
                    <input type="text" name="nama" class="form-control <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                           value="<?php echo e(old('nama')); ?>" required placeholder="Contoh: Frame Kacamata">
                    <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="mb-3">
                    <label class="form-label fw-semibold">Deskripsi</label>
                    <textarea name="deskripsi" class="form-control" rows="3"
                              placeholder="Deskripsi kategori..."><?php echo e(old('deskripsi')); ?></textarea>
                </div>
                <button type="submit" class="btn btn-primary w-100">
                    <i class="bi bi-plus-lg me-1"></i>Tambah Kategori
                </button>
            </form>
        </div>
    </div>
    <?php endif; ?>

    
    <div class="<?php echo e(auth()->user()->can('category.create') ? 'col-md-8' : 'col-12'); ?>">
        <div class="card">
            <div class="card-header p-3">
                <i class="bi bi-tags text-primary me-2"></i>Daftar Kategori
            </div>
            <div class="table-responsive">
                <table class="table mb-0">
                    <thead class="table-light">
                        <tr>
                            <th class="ps-3">#</th>
                            <th>Nama Kategori</th>
                            <th>Deskripsi</th>
                            <th class="text-center">Produk</th>
                            <th class="text-center">Status</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="ps-3 text-muted"><?php echo e($categories->firstItem() + $i); ?></td>
                            <td class="fw-semibold"><?php echo e($cat->nama); ?></td>
                            <td class="text-muted small"><?php echo e($cat->deskripsi ?? '-'); ?></td>
                            <td class="text-center">
                                <span class="badge bg-primary bg-opacity-10 text-primary">
                                    <?php echo e($cat->products_count); ?> produk
                                </span>
                            </td>
                            <td class="text-center">
                                <span class="badge <?php echo e($cat->is_active ? 'bg-success' : 'bg-secondary'); ?>">
                                    <?php echo e($cat->is_active ? 'Aktif' : 'Nonaktif'); ?>

                                </span>
                            </td>
                            <td>
                                <div class="d-flex gap-1">
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('category.edit')): ?>
                                    <button class="btn btn-xs btn-outline-warning"
                                            onclick="editKategori(<?php echo e($cat->id); ?>, '<?php echo e(addslashes($cat->nama)); ?>', '<?php echo e(addslashes($cat->deskripsi)); ?>', <?php echo e($cat->is_active ? 1 : 0); ?>)"
                                            title="Edit">
                                        <i class="bi bi-pencil"></i>
                                    </button>
                                    <?php endif; ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('category.delete')): ?>
                                    <form method="POST" action="<?php echo e(route('categories.destroy', $cat)); ?>"
                                          onsubmit="return confirm('Hapus kategori <?php echo e($cat->nama); ?>?')">
                                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                        <button class="btn btn-xs btn-outline-danger" title="Hapus">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </form>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6" class="text-center text-muted py-4">Belum ada kategori</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <?php if($categories->hasPages()): ?>
            <div class="card-footer"><?php echo e($categories->links()); ?></div>
            <?php endif; ?>
        </div>
    </div>
</div>


<div class="modal fade" id="editModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Edit Kategori</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" id="edit-form">
                <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Nama Kategori <span class="text-danger">*</span></label>
                        <input type="text" name="nama" id="edit-nama" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Deskripsi</label>
                        <textarea name="deskripsi" id="edit-deskripsi" class="form-control" rows="3"></textarea>
                    </div>
                    <div class="form-check form-switch">
                        <input class="form-check-input" type="checkbox" name="is_active" id="edit-active" value="1">
                        <label class="form-check-label" for="edit-active">Aktif</label>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-warning">
                        <i class="bi bi-check-lg me-1"></i>Update
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php $__env->startPush('styles'); ?>
<style>.btn-xs { padding: 3px 8px; font-size: .75rem; }</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
function editKategori(id, nama, deskripsi, isActive) {
    document.getElementById('edit-form').action = `/categories/${id}`;
    document.getElementById('edit-nama').value = nama;
    document.getElementById('edit-deskripsi').value = deskripsi;
    document.getElementById('edit-active').checked = isActive === 1;
    new bootstrap.Modal(document.getElementById('editModal')).show();
}
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /DATA/darrendb/admin.optikperkasa.com/resources/views/admin/categories/index.blade.php ENDPATH**/ ?>