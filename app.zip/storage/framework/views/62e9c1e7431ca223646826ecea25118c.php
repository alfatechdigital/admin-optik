<?php $__env->startSection('title', 'Admin | Edit Format Cetak'); ?>

<?php $__env->startPush('css'); ?>
    <style>
        /* CKEditor editable area height */
        .ck-editor__editable {
            min-height: 600px;
        }

        .editor-container {
            border: 1px solid #ccc;
            border-radius: 8px;
            overflow: hidden;
            background: #fff;
        }

        .header-edit {
            background-color: #f8f9fa;
            border-bottom: 2px solid #e9ecef;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <main id="main" class="main">
        <div class="pagetitle d-flex justify-content-between align-items-center">
            <div>
                <h1>Sunting Format Cetak</h1>
                <nav>
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Home</a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(route('transactions.index')); ?>">Transaksi</a></li>
                        <li class="breadcrumb-item active">Sunting Cetak</li>
                    </ol>
                </nav>
            </div>
            <a href="<?php echo e(route('transactions.index')); ?>" class="btn btn-outline-secondary rounded-pill shadow-sm">
                <i class="bi bi-arrow-left me-1"></i> Kembali
            </a>
        </div>

        <section class="section">
            <div class="row">
                <div class="col-12">
                    <div class="card border-0 shadow-sm" style="border-radius: 18px;">
                        <div class="card-header header-edit d-flex justify-content-between align-items-center p-3"
                            style="border-radius: 18px 18px 0 0;">
                            <h5 class="mb-0 fw-bold text-primary">
                                <i class="bi bi-file-earmark-text me-2"></i> Mode Sunting
                            </h5>
                            <div>
                                <button id="btnSave" class="btn btn-success rounded-pill shadow-sm py-2 px-3 me-2">
                                    <i class="bi bi-save me-1"></i> Simpan
                                </button>
                                <button id="btnPrint" class="btn btn-danger rounded-pill shadow-sm py-2 px-3 me-2">
                                    <i class="bi bi-file-earmark-pdf me-1"></i> Cetak (PDF)
                                </button>
                                <button id="btnDocx" class="btn btn-primary rounded-pill shadow-sm py-2 px-3">
                                    <i class="bi bi-file-earmark-word me-1"></i> Download (DOCX)
                                </button>
                            </div>
                        </div>
                        <div class="card-body p-4">
                            <div class="alert alert-info py-2" role="alert">
                                <i class="bi bi-info-circle me-1"></i> Pastikan untuk klik <strong>Simpan</strong> setelah
                                melakukan perubahan.
                            </div>

                            <div class="editor-container">
                                <div id="editor">
                                    <?php echo $htmlContent; ?>

                                </div>
                            </div>

                            <!-- Iframe for printing -->
                            <iframe id="printIframe" style="display:none;"></iframe>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>

    
    <script id="printStyleData" type="text/plain"><?php echo e($cssContent); ?></script>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <!-- Include CKEditor 5 Build Classic -->
    <script src="https://cdn.ckeditor.com/ckeditor5/39.0.1/classic/ckeditor.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        let myEditor;
        let isEdited = false;

        // Decode the CSS extracted from the print view
        const printStyleEl = document.getElementById('printStyleData');
        const originalCSS = printStyleEl ? printStyleEl.textContent
            .replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&')
            .replace(/&#039;/g, "'").replace(/&quot;/g, '"')
            : '';

        document.addEventListener('DOMContentLoaded', function () {
            ClassicEditor
                .create(document.querySelector('#editor'), {
                    toolbar: ['heading', '|', 'bold', 'italic', 'link', 'bulletedList', 'numberedList', 'blockQuote', '|', 'insertTable', 'undo', 'redo']
                })
                .then(editor => {
                    myEditor = editor;

                    // Inject the original CSS into the CKEditor editable iframe/shadow
                    const editableEl = editor.ui.view.editable.element;
                    if (editableEl && originalCSS) {
                        const styleTag = document.createElement('style');
                        styleTag.textContent = originalCSS;
                        editableEl.prepend(styleTag);
                    }

                    // Track changes
                    editor.model.document.on('change:data', () => {
                        if (!isEdited) {
                            isEdited = true;
                            document.getElementById('btnSave').classList.remove('btn-success');
                            document.getElementById('btnSave').classList.add('btn-warning');
                            document.getElementById('btnSave').innerHTML = '<i class="bi bi-exclamation-circle me-1"></i> Simpan Pilihan';
                        }
                    });
                })
                .catch(error => {
                    console.error(error);
                });

            // Build full HTML with original CSS for output
            function buildFullHTML(bodyContent) {
                return `<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Cetak - <?php echo e($transaction->no_transaksi); ?> - <?php echo e($type); ?></title>
    <style>${originalCSS}</style>
</head>
<body>${bodyContent}</body>
</html>`;
            }

            // Save Button
            document.getElementById('btnSave').addEventListener('click', function () {
                isEdited = false;
                this.classList.remove('btn-warning');
                this.classList.add('btn-success');
                this.innerHTML = '<i class="bi bi-check-circle me-1"></i> Tersimpan';

                Swal.fire({
                    icon: 'success',
                    title: 'Disimpan!',
                    text: 'Perubahan telah disimpan ke dalam sistem sementara. Silahkan cetak atau download file Anda.',
                    toast: true,
                    position: 'bottom-end',
                    showConfirmButton: false,
                    timer: 3000
                });
            });

            // Print / PDF Button
            document.getElementById('btnPrint').addEventListener('click', function () {
                if (isEdited) {
                    Swal.fire({
                        icon: 'warning',
                        title: 'Simpan Dulu',
                        text: 'Anda memiliki perubahan yang belum disimpan. Silahkan klik tombol Simpan terlebih dahulu.'
                    });
                    return;
                }

                const content = myEditor.getData();
                const fullHTML = buildFullHTML(content);
                const iframe = document.getElementById('printIframe');

                const doc = iframe.contentWindow || iframe.contentDocument.document || iframe.contentDocument;
                doc.document.open();
                doc.document.write(fullHTML);
                doc.document.close();

                // Wait for render before printing
                setTimeout(() => {
                    iframe.contentWindow.focus();
                    iframe.contentWindow.print();
                }, 300);
            });

            // Download DOCX Button
            document.getElementById('btnDocx').addEventListener('click', function () {
                if (isEdited) {
                    Swal.fire({
                        icon: 'warning',
                        title: 'Simpan Dulu',
                        text: 'Anda memiliki perubahan yang belum disimpan. Silahkan klik tombol Simpan terlebih dahulu.'
                    });
                    return;
                }

                const content = myEditor.getData();

                // Wrap content in html word schema with original CSS
                var header = "<html xmlns:o='urn:schemas-microsoft-com:office:office' " +
                    "xmlns:w='urn:schemas-microsoft-com:office:word' " +
                    "xmlns='http://www.w3.org/TR/REC-html40'>" +
                    "<head><meta charset='utf-8'><title>Export Document</title>" +
                    "<style>" + originalCSS + "</style>" +
                    "</head><body>";
                var footer = "</body></html>";
                var sourceHTML = header + content + footer;

                var source = 'data:application/vnd.ms-word;charset=utf-8,' + encodeURIComponent(sourceHTML);
                var fileDownload = document.createElement("a");
                document.body.appendChild(fileDownload);
                fileDownload.href = source;
                fileDownload.download = 'dokumen_cetak_<?php echo e($transaction->no_transaksi); ?>_<?php echo e($type); ?>.doc';
                fileDownload.click();
                document.body.removeChild(fileDownload);
            });
        });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\dev\admin-optik\resources\views/admin/transactions/edit-print.blade.php ENDPATH**/ ?>