<?php $__env->startSection('title', 'Akses Ditolak'); ?>
<?php $__env->startSection('code', 'Error 403'); ?>
<?php $__env->startSection('icon'); ?>
    <i class="bi bi-shield-lock"></i>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('message'); ?>
    Anda tidak memiliki izin untuk mengakses halaman ini. Silakan hubungi administrator jika Anda merasa ini adalah kesalahan.
<?php $__env->stopSection(); ?>

<?php echo $__env->make('errors.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\dev\optik-master\resources\views/errors/403.blade.php ENDPATH**/ ?>