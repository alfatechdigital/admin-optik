<?php $__env->startSection('title', 'Sesi Berakhir'); ?>
<?php $__env->startSection('code', 'Error 419'); ?>
<?php $__env->startSection('icon'); ?>
    <i class="bi bi-clock-history"></i>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('message'); ?>
    Sesi Anda telah berakhir karena tidak ada aktivitas dalam waktu yang lama. Silakan segarkan halaman dan coba lagi.
<?php $__env->stopSection(); ?>

<?php echo $__env->make('errors.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\dev\optik-master\resources\views/errors/419.blade.php ENDPATH**/ ?>