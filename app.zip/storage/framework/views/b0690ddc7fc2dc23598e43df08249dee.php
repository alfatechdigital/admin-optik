<?php $__env->startSection('title', 'Data Pasien'); ?>
<?php $__env->startSection('page-title', 'Data Pasien'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header p-3 d-flex flex-wrap gap-2 justify-content-between align-items-center">
        <div class="fw-semibold"><i class="bi bi-people text-primary me-2"></i>Daftar Pasien</div>
        <div class="d-flex gap-2 flex-wrap">
            <form class="d-flex gap-2" method="GET">
                <input type="text" name="search" class="form-control form-control-sm"
                       placeholder="Cari nama / No. RM..." value="<?php echo e(request('search')); ?>" style="width:220px">
                <button class="btn btn-sm btn-outline-secondary"><i class="bi bi-search"></i></button>
            </form>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('patient.create')): ?>
            <a href="<?php echo e(route('patients.create')); ?>" class="btn btn-sm btn-primary">
                <i class="bi bi-plus-lg me-1"></i>Tambah Pasien
            </a>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('patient.view')): ?>
            <a href="<?php echo e(route('patients.export')); ?>" class="btn btn-sm btn-success">
                <i class="bi bi-download me-1"></i>Export Excel
            </a>
            <button class="btn btn-sm btn-info" data-bs-toggle="modal" data-bs-target="#importModal">
                <i class="bi bi-upload me-1"></i>Import Excel
            </button>
            <?php endif; ?>
        </div>
    </div>
    <div class="table-responsive">
        <table class="table mb-0">
            <thead class="table-light">
                <tr>
                    <th class="ps-3">#</th>
                    <th>No. RM</th>
                    <th>Nama</th>
                    <th>Tanggal Lahir</th>
                    <th>J/K</th>
                    <th>No. HP</th>
                    <th>No. BPJS</th>
                    <th>Kunjungan Terakhir</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td class="ps-3 text-muted"><?php echo e($patients->firstItem() + $i); ?></td>
                    <td><span class="badge bg-secondary"><?php echo e($p->no_rm); ?></span></td>
                    <td>
                        <a href="<?php echo e(route('patients.show', $p)); ?>" class="fw-semibold text-decoration-none">
                            <?php echo e($p->nama); ?>

                        </a>
                        <?php if($p->tanggal_lahir): ?>
                        <div class="text-muted" style="font-size:.75rem"><?php echo e($p->umur); ?> tahun</div>
                        <?php endif; ?>
                    </td>
                    <td><?php echo e($p->tanggal_lahir ? $p->tanggal_lahir->format('d-m-Y') : '-'); ?></td>
                    <td><?php echo e($p->jenis_kelamin == 'L' ? 'Laki-laki' : ($p->jenis_kelamin == 'P' ? 'Perempuan' : '-')); ?></td>
                    <td><?php echo e($p->no_hp ?? '-'); ?></td>
                    <td><?php echo e($p->no_bpjs ?? '-'); ?></td>
                    <td>
                        <?php if($p->latestRecord): ?>
                            <?php echo e($p->latestRecord->visit_date->format('d M Y')); ?>

                        <?php else: ?>
                            <span class="text-muted">Belum ada</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <div class="d-flex gap-1">
                            <a href="<?php echo e(route('patients.show', $p)); ?>" class="btn btn-xs btn-outline-info" title="Detail">
                                <i class="bi bi-eye"></i>
                            </a>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('patient.edit')): ?>
                            <a href="<?php echo e(route('patients.edit', $p)); ?>" class="btn btn-xs btn-outline-warning" title="Edit">
                                <i class="bi bi-pencil"></i>
                            </a>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('patient.delete')): ?>
                            <form method="POST" action="<?php echo e(route('patients.destroy', $p)); ?>"
                                  onsubmit="return confirm('Hapus pasien <?php echo e($p->nama); ?>?')">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                <button class="btn btn-xs btn-outline-danger" title="Hapus">
                                    <i class="bi bi-trash"></i>
                                </button>
                            </form>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="8" class="text-center text-muted py-5">
                        <i class="bi bi-people fs-1 d-block mb-2 opacity-25"></i>
                        Belum ada data pasien
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php if($patients->hasPages()): ?>
    <div class="card-footer">
        <?php echo e($patients->links()); ?>

    </div>
    <?php endif; ?>
</div>

<?php $__env->startPush('styles'); ?>
<style>.btn-xs { padding: 3px 8px; font-size: .75rem; }</style>
<?php $__env->stopPush(); ?>

<!-- Modal Import -->
<div class="modal fade" id="importModal" tabindex="-1" aria-labelledby="importModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="importModalLabel">Import Data Pasien</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="<?php echo e(route('patients.import')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="file" class="form-label">Pilih File Excel (.xlsx, .xls, .csv)</label>
                        <input type="file" class="form-control" id="file" name="file" accept=".xlsx,.xls,.csv" required>
                        <div class="form-text">
                        <a href="/template.xlsx">download template</a>    
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary">Import</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\dev\admin-optik\resources\views/admin/patients/index.blade.php ENDPATH**/ ?>