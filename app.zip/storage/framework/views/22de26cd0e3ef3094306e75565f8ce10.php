<?php $__env->startSection('title', 'Edit Produk'); ?>
<?php $__env->startSection('page-title', 'Edit Produk'); ?>

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
<div class="col-xl-9">
<form method="POST" action="<?php echo e(route('products.update', $product)); ?>" enctype="multipart/form-data">
<?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>

<div class="card mb-3">
    <div class="card-header p-3">
        <i class="bi bi-pencil text-warning me-2"></i>Edit: <?php echo e($product->nama); ?>

        <span class="badge bg-secondary ms-2"><?php echo e($product->kode_produk); ?></span>
    </div>
    <div class="card-body p-4">
        <div class="row g-3">
            <div class="col-md-8">
                <label class="form-label fw-semibold">Nama Produk <span class="text-danger">*</span></label>
                <input type="text" name="nama" class="form-control <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                       value="<?php echo e(old('nama', $product->nama)); ?>" required>
                <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-md-4">
                <label class="form-label fw-semibold">Merek</label>
                <input type="text" name="merek" class="form-control" value="<?php echo e(old('merek', $product->merek)); ?>">
            </div>
            <div class="col-md-6">
                <label class="form-label fw-semibold">Kategori <span class="text-danger">*</span></label>
                <select name="category_id" class="form-select" required>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($cat->id); ?>"
                        <?php echo e(old('category_id', $product->category_id) == $cat->id ? 'selected' : ''); ?>>
                        <?php echo e($cat->nama); ?>

                    </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-3">
                <label class="form-label fw-semibold">Satuan</label>
                <select name="satuan" class="form-select">
                    <?php $__currentLoopData = ['pcs','pasang','box','lusin']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($s); ?>" <?php echo e(old('satuan',$product->satuan)==$s?'selected':''); ?>><?php echo e($s); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-3">
                <label class="form-label fw-semibold">Status</label>
                <div class="form-check form-switch mt-2">
                    <input class="form-check-input" type="checkbox" name="is_active" id="is_active"
                           value="1" <?php echo e(old('is_active', $product->is_active) ? 'checked' : ''); ?>>
                    <label class="form-check-label" for="is_active">Produk Aktif</label>
                </div>
            </div>
            <div class="col-12">
                <label class="form-label fw-semibold">Deskripsi</label>
                <textarea name="deskripsi" class="form-control" rows="3"><?php echo e(old('deskripsi', $product->deskripsi)); ?></textarea>
            </div>
        </div>
    </div>
</div>

<div class="card mb-3">
    <div class="card-header p-3"><i class="bi bi-currency-dollar text-success me-2"></i>Harga & Stok</div>
    <div class="card-body p-4">
        <div class="row g-3">
            <div class="col-md-3">
                <label class="form-label fw-semibold">Harga Beli <span class="text-danger">*</span></label>
                <div class="input-group">
                    <span class="input-group-text">Rp</span>
                    <input type="number" name="harga_beli" class="form-control"
                           value="<?php echo e(old('harga_beli', $product->harga_beli)); ?>" min="0" required>
                </div>
            </div>
            <div class="col-md-3">
                <label class="form-label fw-semibold">Harga Jual <span class="text-danger">*</span></label>
                <div class="input-group">
                    <span class="input-group-text">Rp</span>
                    <input type="number" name="harga_jual" class="form-control"
                           value="<?php echo e(old('harga_jual', $product->harga_jual)); ?>" min="0" required>
                </div>
            </div>
            <div class="col-md-3">
                <label class="form-label fw-semibold">Stok Saat Ini <span class="text-danger">*</span></label>
                <input type="number" name="stok" class="form-control"
                       value="<?php echo e(old('stok', $product->stok)); ?>" min="0" required>
            </div>
            <div class="col-md-3">
                <label class="form-label fw-semibold">Minimum Stok</label>
                <input type="number" name="stok_minimum" class="form-control"
                       value="<?php echo e(old('stok_minimum', $product->stok_minimum)); ?>" min="0">
            </div>
        </div>
    </div>
</div>

<div class="card mb-3">
    <div class="card-header p-3"><i class="bi bi-image text-info me-2"></i>Foto Produk</div>
    <div class="card-body p-4">
        <div class="row align-items-center g-3">
        </div>
    </div>
</div>

<div class="d-flex gap-2">
    <button type="submit" class="btn btn-warning px-4">
        <i class="bi bi-check-lg me-1"></i>Update Produk
    </button>
    <a href="<?php echo e(route('products.index')); ?>" class="btn btn-outline-secondary">Batal</a>
</div>
</form>
</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\dev\admin-optik\resources\views/admin/products/edit.blade.php ENDPATH**/ ?>