<style>
    .input-compact {
        min-width: 75px;
        text-align: center;
    }
</style>


<?php $__env->startSection('title', 'Rekam Medis Baru'); ?>
<?php $__env->startSection('page-title', 'Input Rekam Medis'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center">
        <div class="col-xl-10">
            <form method="POST" action="<?php echo e(route('medical-records.store')); ?>">
                <?php echo csrf_field(); ?>

                
                <div class="card mb-3">
                    <div class="card-header p-3"><i class="bi bi-person text-primary me-2"></i>Data Pasien & Kunjungan</div>
                    <div class="card-body p-4">
                        <div class="row g-3">
                            <div class="col-md-5">
                                <label class="form-label fw-semibold">
                                    Pasien <span class="text-danger">*</span>
                                </label>

                                
                                <input type="hidden" name="patient_id" id="patient_id"
                                    value="<?php echo e(old('patient_id', $selectedPatient?->id)); ?>">

                                
                                <input type="text" id="patient_search"
                                    class="form-control <?php $__errorArgs = ['patient_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    placeholder="Cari No RM / Nama pasien..."
                                    value="<?php echo e(old('patient_id') ? $selectedPatient?->no_rm . ' — ' . $selectedPatient?->nama : ''); ?>"
                                    autocomplete="off" required>

                                
                                <div id="patient_result" class="list-group position-absolute w-100 shadow"
                                    style="z-index:1000;"></div>

                                <?php $__errorArgs = ['patient_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label fw-semibold">
                                    Dokter / Pemeriksa <span class="text-danger">*</span>
                                </label>

                                <input type="text" name="nama_dokter" id="doctor_search"
                                    class="form-control <?php $__errorArgs = ['nama_dokter'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    value="<?php echo e(old('nama_dokter', auth()->user()->name)); ?>"
                                    placeholder="Masukkan nama dokter" autocomplete="off" required>

                                
                                <div id="doctor_result" class="list-group position-absolute w-100 shadow"
                                    style="z-index:1000;"></div>

                                <?php $__errorArgs = ['nama_dokter'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-3">
                                <label class="form-label fw-semibold">Tanggal Kunjungan <span
                                        class="text-danger">*</span></label>
                                <input type="date" name="tanggal_kunjungan"
                                    class="form-control <?php $__errorArgs = ['tanggal_kunjungan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    value="<?php echo e(old('tanggal_kunjungan', today()->format('Y-m-d'))); ?>" required>
                                <?php $__errorArgs = ['tanggal_kunjungan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-12">
                                <label class="form-label fw-semibold">Keluhan Utama</label>
                                <input type="text" name="keluhan" class="form-control" value="<?php echo e(old('keluhan')); ?>"
                                    placeholder="Penglihatan buram, mata lelah, sakit kepala...">
                            </div>
                        </div>
                    </div>
                </div>

                
                <div class="card mb-3">
                    <div class="card-header fw-semibold">Ukuran Kacamata Lama</div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered align-middle text-center">
                                <thead>
                                    <tr>
                                        <th></th>
                                        <th>SPH</th>
                                        <th>CYL</th>
                                        <th>AXIS</th>
                                        <th>PRISM</th>
                                        <th>ADD</th>
                                        <th>MPD</th>
                                        <th>CC</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <th>
                                            <span class="badge bg-danger fs-6">OD</span>
                                            <div class="text-muted" style="font-size:.72rem">Kanan</div>
                                        </th>
                                        <td><input type="text" name="og_od_sph" class="form-control input-compact"
                                                step="0.25" min="-30" max="30" placeholder="-"></td>
                                        <td><input type="text" name="og_od_cyl" class="form-control input-compact"
                                                step="0.25" min="-30" max="30" placeholder="-"></td>
                                        <td><input type="text" name="og_od_axis" class="form-control input-compact"
                                                step="0.25" min="-30" max="30" placeholder="-"></td>
                                        <td><input type="text" name="og_od_prism" class="form-control input-compact"
                                                step="0.25" min="-30" max="30" placeholder="-"></td>
                                        <td><input type="text" name="og_od_add" class="form-control input-compact"
                                                step="0.25" min="-30" max="30" placeholder="-"></td>
                                        <td><input type="text" name="og_od_mpd" class="form-control input-compact"
                                                step="0.25" min="-30" max="30" placeholder="-"></td>
                                        <td><input type="text" name="og_od_cc" class="form-control input-compact"
                                                placeholder="-"></td>
                                    </tr>
                                    <tr>
                                        <th>
                                            <span class="badge bg-info fs-6">OS</span>
                                            <div class="text-muted style=" font-size:.72rem">Kiri</div>
                                        </th>
                                        <td><input type="text" name="og_os_sph" class="form-control input-compact"
                                                step="0.25" min="-30" max="30" placeholder="-"></td>
                                        <td><input type="text" name="og_os_cyl" class="form-control input-compact"
                                                step="0.25" min="-30" max="30" placeholder="-"></td>
                                        <td><input type="text" name="og_os_axis" class="form-control input-compact"
                                                step="0.25" min="-30" max="30" placeholder="-"></td>
                                        <td><input type="text" name="og_os_prism" class="form-control input-compact"
                                                step="0.25" min="-30" max="30" placeholder="-"></td>
                                        <td><input type="text" name="og_os_add" class="form-control input-compact"
                                                step="0.25" min="-30" max="30" placeholder="-"></td>
                                        <td><input type="text" name="og_os_mpd" class="form-control input-compact"
                                                step="0.25" min="-30" max="30" placeholder="-"></td>
                                        <td><input type="text" name="og_os_cc" class="form-control input-compact"
                                                placeholder="-"></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                
                <div class="card mb-3">
                    <div class="card-header fw-semibold">Ukuran Resep Dokter</div>
                    <div class="card-body">

                        <div class="table-responsive mb-3">
                            <table class="table table-bordered align-middle text-center">
                                <thead>
                                    <tr>
                                        <th></th>
                                        <th>SPH</th>
                                        <th>CYL</th>
                                        <th>AXIS</th>
                                        <th>PRISM</th>
                                        <th>ADD</th>
                                        <th>MPD</th>
                                        <th>CC</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <th>
                                            <span class="badge bg-danger fs-6">OD</span>
                                            <div class="text-muted" style="font-size:.72rem">Kanan</div>
                                        </th>
                                        <td><input type="text" name="presc_od_sph" class="form-control input-compact"
                                                step="0.25" min="-30" max="30" placeholder="-"></td>
                                        <td><input type="text" name="presc_od_cyl" class="form-control input-compact"
                                                step="0.25" min="-30" max="30" placeholder="-"></td>
                                        <td><input type="text" name="presc_od_axis" class="form-control input-compact"
                                                step="0.25" min="-30" max="30" placeholder="-"></td>
                                        <td><input type="text" name="presc_od_prism" class="form-control input-compact"
                                                step="0.25" min="-30" max="30" placeholder="-"></td>
                                        <td><input type="text" name="presc_od_add" class="form-control input-compact"
                                                step="0.25" min="-30" max="30" placeholder="-"></td>
                                        <td><input type="text" name="presc_od_mpd" class="form-control input-compact"
                                                step="0.25" min="-30" max="30" placeholder="-"></td>
                                        <td><input type="text" name="presc_od_cc" class="form-control input-compact"
                                                placeholder="-"></td>
                                    </tr>
                                    <tr>
                                        <th>
                                            <span class="badge bg-info fs-6">OS</span>
                                            <div class="text-muted" style="font-size:.72rem">Kiri</div>
                                        </th>
                                        <td><input type="text" name="presc_os_sph" class="form-control input-compact"
                                                step="0.25" min="-30" max="30" placeholder="-"></td>
                                        <td><input type="text" name="presc_os_cyl" class="form-control input-compact"
                                                step="0.25" min="-30" max="30" placeholder="-"></td>
                                        <td><input type="text" name="presc_os_axis" class="form-control input-compact"
                                                step="0.25" min="-30" max="30" placeholder="-"></td>
                                        <td><input type="text" name="presc_os_prism" class="form-control input-compact"
                                                step="0.25" min="-30" max="30" placeholder="-"></td>
                                        <td><input type="text" name="presc_os_add" class="form-control input-compact"
                                                step="0.25" min="-30" max="30" placeholder="-"></td>
                                        <td><input type="text" name="presc_os_mpd" class="form-control input-compact"
                                                step="0.25" min="-30" max="30" placeholder="-"></td>
                                        <td><input type="text" name="presc_os_cc" class="form-control input-compact"
                                                placeholder="-"></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>

                        <div class="row">
                            
                            <div class="col-md-4">
                                <label class="form-label fw-semibold">
                                    Diagnosa</span>
                                </label>

                                
                                <input type="text" id="rx_diagnosis_search" name="presc_diagnosis"
                                    class="form-control <?php $__errorArgs = ['presc_diagnosis'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    placeholder="Cari atau ketik Diagnosa..."
                                    value="<?php echo e(old('presc_diagnosis', $selectedDiagnosis?->name)); ?>" autocomplete="off">

                                
                                <div id="rx_diagnosis_result" class="list-group position-absolute w-100 shadow"
                                    style="z-index:1000;"></div>

                                <?php $__errorArgs = ['presc_diagnosis'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-md-4">
                                <label class="form-label fw-semibold">Asal Resep / Dokter</label>
                                <input type="text" name="presc_doctor_name" class="form-control">
                            </div>

                            <div class="col-md-4">
                                <label class="form-label fw-semibold">Tanggal Resep</label>
                                <input type="date" name="presc_exam_date" class="form-control">
                            </div>

                            <div class="col-md-12 mt-2">
                                <label class="form-label fw-semibold">Keterangan</label>
                                <input type="text" name="presc_notes" class="form-control">
                            </div>
                        </div>

                    </div>
                </div>

                
                <div class="card mb-3">
                    <div class="card-header fw-semibold">Hasil Refraksi</div>
                    <div class="card-body">

                        <div class="table-responsive mb-3">
                            <table class="table table-bordered align-middle text-center">
                                <thead>
                                    <tr>
                                        <th></th>
                                        <th>SC</th>
                                        <th>SPH</th>
                                        <th>CYL</th>
                                        <th>AXIS</th>
                                        <th>PRISM</th>
                                        <th>ADD</th>
                                        <th>MPD</th>
                                        <th>CC</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <th>
                                            <span class="badge bg-danger fs-6">OD</span>
                                            <div class="text-muted" style="font-size:.72rem">Kanan</div>
                                        </th>
                                        <td><input type="text" name="ref_od_sc" class="form-control input-compact"
                                                placeholder="-"></td>
                                        <td><input type="text" name="ref_od_sph" class="form-control input-compact"
                                                step="0.25" min="-30" max="30" placeholder="-"></td>
                                        <td><input type="text" name="ref_od_cyl" class="form-control input-compact"
                                                step="0.25" min="-30" max="30" placeholder="-"></td>
                                        <td><input type="text" name="ref_od_axis" class="form-control input-compact"
                                                step="0.25" min="-30" max="30" placeholder="-"></td>
                                        <td><input type="text" name="ref_od_prism" class="form-control input-compact"
                                                step="0.25" min="-30" max="30" placeholder="-"></td>
                                        <td><input type="text" name="ref_od_add" class="form-control input-compact"
                                                step="0.25" min="-30" max="30" placeholder="-"></td>
                                        <td><input type="text" name="ref_od_mpd" class="form-control input-compact"
                                                step="0.25" min="-30" max="30" placeholder="-"></td>
                                        <td><input type="text" name="ref_od_cc" class="form-control input-compact"
                                                placeholder="-"></td>
                                    </tr>
                                    <tr>
                                        <th>
                                            <span class="badge bg-info fs-6">OS</span>
                                            <div class="text-muted style=" font-size:.72rem">Kiri</div>
                                        </th>
                                        <td><input type="text" name="ref_os_sc" class="form-control input-compact"
                                                placeholder="-"></td>
                                        <td><input type="text" name="ref_os_sph" class="form-control input-compact"
                                                step="0.25" min="-30" max="30" placeholder="-"></td>
                                        <td><input type="text" name="ref_os_cyl" class="form-control input-compact"
                                                step="0.25" min="-30" max="30" placeholder="-"></td>
                                        <td><input type="text" name="ref_os_axis" class="form-control input-compact"
                                                step="0.25" min="-30" max="30" placeholder="-"></td>
                                        <td><input type="text" name="ref_os_prism" class="form-control input-compact"
                                                step="0.25" min="-30" max="30" placeholder="-"></td>
                                        <td><input type="text" name="ref_os_add" class="form-control input-compact"
                                                step="0.25" min="-30" max="30" placeholder="-"></td>
                                        <td><input type="text" name="ref_os_mpd" class="form-control input-compact"
                                                step="0.25" min="-30" max="30" placeholder="-"></td>
                                        <td><input type="text" name="ref_os_cc" class="form-control input-compact"
                                                placeholder="-"></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>

                        <div class="row">
                            
                            <div class="col-md-4">
                                <label class="form-label fw-semibold">
                                    Diagnosa</span>
                                </label>

                                
                                <input type="text" id="ref_diagnosis_search" name="ref_diagnosis"
                                    class="form-control <?php $__errorArgs = ['ref_diagnosis'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    placeholder="Cari atau ketik Diagnosa..."
                                    value="<?php echo e(old('ref_diagnosis', $selectedDiagnosis?->name)); ?>" autocomplete="off">

                                
                                <div id="ref_diagnosis_result" class="list-group position-absolute w-100 shadow"
                                    style="z-index:1000;"></div>

                                <?php $__errorArgs = ['ref_diagnosis'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-md-4">
                                <label class="form-label fw-semibold">Asal Resep / Dokter</label>
                                <input type="text" name="ref_doctor_name" class="form-control">
                            </div>

                            <div class="col-md-4">
                                <label class="form-label fw-semibold">Tanggal Resep</label>
                                <input type="date" name="ref_exam_date" class="form-control">
                            </div>

                            <div class="col-md-12 mt-2">
                                <label class="form-label fw-semibold">Keterangan</label>
                                <input type="text" name="ref_notes" class="form-control">
                            </div>
                        </div>

                    </div>
                </div>

                
                <div class="d-flex gap-2">
                    <button type="submit" class="btn btn-primary px-4">
                        <i class="bi bi-check-lg me-1"></i>Simpan Rekam Medis
                    </button>
                    <a href="<?php echo e(route('medical-records.index')); ?>" class="btn btn-outline-secondary">Batal</a>
                </div>

            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        const input = document.getElementById('patient_search');
        const resultBox = document.getElementById('patient_result');
        const hidden = document.getElementById('patient_id');

        let timeout = null;

        input.addEventListener('keyup', function () {
            const query = this.value;

            clearTimeout(timeout);

            if (query.length < 2) {
                resultBox.innerHTML = '';
                return;
            }

            timeout = setTimeout(() => {
                fetch(`<?php echo e(route('patients.autocomplete')); ?>?q=${query}`)
                    .then(res => res.json())
                    .then(data => {
                        resultBox.innerHTML = '';

                        data.forEach(item => {
                            const el = document.createElement('a');
                            el.href = "#";
                            el.classList.add('list-group-item', 'list-group-item-action');
                            el.textContent = `${item.no_rm} — ${item.nama}`;

                            el.addEventListener('click', function (e) {
                                e.preventDefault();
                                input.value = `${item.no_rm} — ${item.nama}`;
                                hidden.value = item.id;
                                resultBox.innerHTML = '';
                            });

                            resultBox.appendChild(el);
                        });
                    });
            }, 300);
        });

        // klik luar -> close dropdown
        document.addEventListener('click', function (e) {
            if (!input.contains(e.target)) {
                resultBox.innerHTML = '';
            }
        });
    });

    // refraksi diagnosis autocomplete
    document.addEventListener('DOMContentLoaded', function () {
        const input = document.getElementById('ref_diagnosis_search');
        const resultBox = document.getElementById('ref_diagnosis_result');

        let timeout = null;

        input.addEventListener('keyup', function () {
            const query = this.value;

            clearTimeout(timeout);

            if (query.length < 2) {
                resultBox.innerHTML = '';
                return;
            }

            timeout = setTimeout(() => {
                fetch(`<?php echo e(route('diagnoses.search')); ?>?q=${query}`)
                    .then(res => res.json())
                    .then(data => {
                        resultBox.innerHTML = '';

                        data.forEach(item => {
                            const el = document.createElement('a');
                            el.href = "#";
                            el.classList.add('list-group-item', 'list-group-item-action');
                            el.textContent = `${item.name}`;

                            el.addEventListener('click', function (e) {
                                e.preventDefault();
                                input.value = `${item.name}`;
                                resultBox.innerHTML = '';
                            });

                            resultBox.appendChild(el);
                        });
                    });
            }, 300);
        });

        // klik luar -> close dropdown
        document.addEventListener('click', function (e) {
            if (!input.contains(e.target)) {
                resultBox.innerHTML = '';
            }
        });
    });

    // recipe diagnosis autocomplete
    document.addEventListener('DOMContentLoaded', function () {
        const input = document.getElementById('rx_diagnosis_search');
        const resultBox = document.getElementById('rx_diagnosis_result');

        let timeout = null;

        input.addEventListener('keyup', function () {
            const query = this.value;

            clearTimeout(timeout);

            if (query.length < 2) {
                resultBox.innerHTML = '';
                return;
            }

            timeout = setTimeout(() => {
                fetch(`<?php echo e(route('diagnoses.search')); ?>?q=${query}`)
                    .then(res => res.json())
                    .then(data => {
                        resultBox.innerHTML = '';

                        data.forEach(item => {
                            const el = document.createElement('a');
                            el.href = "#";
                            el.classList.add('list-group-item', 'list-group-item-action');
                            el.textContent = `${item.name}`;

                            el.addEventListener('click', function (e) {
                                e.preventDefault();
                                input.value = `${item.name}`;
                                resultBox.innerHTML = '';
                            });

                            resultBox.appendChild(el);
                        });
                    });
            }, 300);
        });

        // klik luar -> close dropdown
        document.addEventListener('click', function (e) {
            if (!input.contains(e.target)) {
                resultBox.innerHTML = '';
            }
        });
    });

    // doctor autocomplete
    document.addEventListener('DOMContentLoaded', function () {
        const input = document.getElementById('doctor_search');
        const resultBox = document.getElementById('doctor_result');

        let timeout = null;

        input.addEventListener('keyup', function () {
            const query = this.value;

            clearTimeout(timeout);

            if (query.length < 2) {
                resultBox.innerHTML = '';
                return;
            }

            timeout = setTimeout(() => {
                fetch(`<?php echo e(route('doctors.autocomplete')); ?>?q=${query}`)
                    .then(res => res.json())
                    .then(data => {
                        resultBox.innerHTML = '';

                        data.forEach(item => {
                            const el = document.createElement('a');
                            el.href = "#";
                            el.classList.add('list-group-item', 'list-group-item-action');
                            el.textContent = `${item.name}`;

                            el.addEventListener('click', function (e) {
                                e.preventDefault();
                                input.value = `${item.name}`;
                                resultBox.innerHTML = '';
                            });

                            resultBox.appendChild(el);
                        });
                    });
            }, 300);
        });

        // klik luar -> close dropdown
        document.addEventListener('click', function (e) {
            if (!input.contains(e.target)) {
                resultBox.innerHTML = '';
            }
        });
    });
</script>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\dev\optik-master\resources\views/admin/medical-records/create.blade.php ENDPATH**/ ?>