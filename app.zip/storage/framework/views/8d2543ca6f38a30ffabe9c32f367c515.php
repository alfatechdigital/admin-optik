<?php $__env->startSection('title', 'Rekam Medis'); ?>
<?php $__env->startSection('page-title', 'Rekam Medis'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header p-3 d-flex flex-wrap gap-2 justify-content-between align-items-center">
        <div><i class="bi bi-clipboard2-pulse text-primary me-2"></i>Daftar Rekam Medis</div>
        <div class="d-flex flex-wrap gap-2">
            <form class="d-flex flex-wrap gap-2" method="GET">
                <input type="text" name="search" class="form-control form-control-sm"
                       placeholder="Nama / No. RM..." value="<?php echo e(request('search')); ?>" style="width:200px">
                <input type="date" name="from" class="form-control form-control-sm"
                       value="<?php echo e(request('from')); ?>" style="width:140px">
                <input type="date" name="to" class="form-control form-control-sm"
                       value="<?php echo e(request('to')); ?>" style="width:140px">
                <button class="btn btn-sm btn-outline-secondary"><i class="bi bi-search"></i></button>
            </form>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('medical_record.create')): ?>
            <a href="<?php echo e(route('medical-records.create')); ?>" class="btn btn-sm btn-primary">
                <i class="bi bi-plus-lg me-1"></i>Rekam Medis Baru
            </a>
            <?php endif; ?>
        </div>
    </div>
    <div class="table-responsive">
        <table class="table mb-0">
            <thead class="table-light">
                <tr>
                    <th class="ps-3">#</th>
                    <th>Tanggal</th>
                    <th>No. RM</th>
                    <th>Pasien</th>
                    <th>OD (Kanan)</th>
                    <th>OS (Kiri)</th>
                    <th>Created By</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $rm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td class="ps-3 text-muted"><?php echo e($records->firstItem() + $i); ?></td>
                    <td>
                        <span class="badge bg-primary bg-opacity-10 text-primary">
                            <?php echo e($rm->visit_date->format('d M Y')); ?>

                        </span>
                    </td>
                    <td><span class="badge bg-secondary"><?php echo e($rm->patient?->no_rm ?? '-'); ?></span></td>
                   <td class="fw-semibold">
    <a href="<?php echo e(route('medical-records.show', $rm)); ?>" class="text-secondary-emphasis text-decoration-none">
        <?php echo e($rm->patient?->nama ?? 'Pasien Tidak Ditemukan / Dihapus'); ?>

    </a>
</td>
                    <td style="font-size:.82rem">
                        <span class="text-muted">SPH</span> <?php echo e($rm->formatResep($rm->od_sph)); ?>

                        <span class="text-muted ms-1">CYL</span> <?php echo e($rm->formatResep($rm->od_cyl)); ?>

                    </td>
                    <td style="font-size:.82rem">
                        <span class="text-muted">SPH</span> <?php echo e($rm->formatResep($rm->os_sph)); ?>

                        <span class="text-muted ms-1">CYL</span> <?php echo e($rm->formatResep($rm->os_cyl)); ?>

                    </td>
                    <td class="text-muted small"><?php echo e($rm->createdBy->name ?? '-'); ?></td>
                    <td>
                        <div class="d-flex gap-1">
                            <a href="<?php echo e(route('medical-records.show', $rm)); ?>" class="btn btn-xs btn-outline-info" title="Detail">
                                <i class="bi bi-eye"></i>
                            </a>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('medical_record.edit')): ?>
                            <a href="<?php echo e(route('medical-records.edit', $rm)); ?>" class="btn btn-xs btn-outline-warning" title="Edit">
                                <i class="bi bi-pencil"></i>
                            </a>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('medical_record.delete')): ?>
                            <form method="POST" action="<?php echo e(route('medical-records.destroy', $rm)); ?>"
                                  onsubmit="return confirm('Hapus rekam medis ini?')">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                <button class="btn btn-xs btn-outline-danger"><i class="bi bi-trash"></i></button>
                            </form>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
                
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="8" class="text-center text-muted py-5">
                        <i class="bi bi-clipboard2 fs-1 d-block mb-2 opacity-25"></i>
                        Belum ada rekam medis
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php if($records->hasPages()): ?>
    <div class="card-footer"><?php echo e($records->links()); ?></div>
    <?php endif; ?>
</div>

<?php $__env->startPush('styles'); ?>
<style>.btn-xs { padding: 3px 8px; font-size: .75rem; }</style>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /DATA/darrendb/admin.optikperkasa.com/resources/views/admin/medical-records/index.blade.php ENDPATH**/ ?>