<style>
    .column-compact {
        min-width: 50px;
        max-width: 65px;
        text-align: center;
    }
</style>



<?php $__env->startSection('title', 'Detail Rekam Medis'); ?>
<?php $__env->startSection('page-title', 'Detail Rekam Medis'); ?>

<?php $__env->startSection('content'); ?>
    <?php
        // Formatter: leaves value as-is according to user input, returns '-' if null/empty
        $fmt = fn($v) => (is_null($v) || $v === '') ? '-' : $v;
    ?>
    <div class="row justify-content-center">
        <div class="col-xl-9">

            
            <div class="card mb-3">
                <div class="card-body p-4">
                    <div class="d-flex justify-content-between align-items-start flex-wrap gap-3">
                        <div>
                            <h5 class="fw-bold mb-1"><?php echo e($medicalRecord->patient->nama); ?></h5>
                            <span class="badge bg-secondary me-2"><?php echo e($medicalRecord->patient->no_rm); ?></span>
                            <span class="badge bg-primary"><?php echo e($medicalRecord->visit_date->format('d M Y')); ?></span>
                        </div>
                        <div class="d-flex gap-2">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('medical_record.edit')): ?>
                                <a href="<?php echo e(route('medical-records.edit', $medicalRecord)); ?>" class="btn btn-warning btn-sm">
                                    <i class="bi bi-pencil me-1"></i>Edit
                                </a>
                            <?php endif; ?>
                            <button onclick="window.print()" class="btn btn-outline-secondary btn-sm">
                                <i class="bi bi-printer me-1"></i>Cetak
                            </button>
                        </div>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="col-12">
                            <table class="table table-sm table-borderless mb-0">
                                <tr>
                                    <td class="text-muted ps-0">Keluhan</td>
                                    <td>: <?php echo e($medicalRecord->complaint ?? '-'); ?></td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            
            <div class="card mb-3">
                <div class="card-header fw-semibold">Ukuran Kacamata Lama</div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered align-middle text-center">
                            <thead>
                                <tr>
                                    <th></th>
                                    <th>SPH</th>
                                    <th>CYL</th>
                                    <th>AXIS</th>
                                    <th>PRISM</th>
                                    <th>ADD</th>
                                    <th>MPD</th>
                                    <th>CC</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <th>
                                        <span class="badge bg-danger fs-6">OD</span>
                                        <div class="text-muted" style="font-size:.72rem">Kanan</div>
                                    </th>
                                    <td class="column-compact">
                                        <span><?php echo e($fmt($medicalRecord->oldGlasses->od_sph ?? null)); ?></span></td>
                                    <td class="column-compact">
                                        <span><?php echo e($fmt($medicalRecord->oldGlasses->od_cyl ?? null)); ?></span></td>
                                    <td class="column-compact">
                                        <span><?php echo e($fmt($medicalRecord->oldGlasses->od_axis ?? null)); ?></span></td>
                                    <td class="column-compact">
                                        <span><?php echo e($fmt($medicalRecord->oldGlasses->od_prism ?? null)); ?></span></td>
                                    <td class="column-compact">
                                        <span><?php echo e($fmt($medicalRecord->oldGlasses->od_add ?? null)); ?></span></td>
                                    <td class="column-compact">
                                        <span><?php echo e($fmt($medicalRecord->oldGlasses->od_mpd ?? null)); ?></span></td>
                                    <td class="column-compact">
                                        <span><?php echo e($fmt($medicalRecord->oldGlasses->od_cc ?? null)); ?></span></td>
                                </tr>
                                <tr>
                                    <th>
                                        <span class="badge bg-info fs-6">OS</span>
                                        <div class="text-muted" style="font-size:.72rem">Kiri</div>
                                    </th>
                                    <td class="column-compact">
                                        <span><?php echo e($fmt($medicalRecord->oldGlasses->os_sph ?? null)); ?></span></td>
                                    <td class="column-compact">
                                        <span><?php echo e($fmt($medicalRecord->oldGlasses->os_cyl ?? null)); ?></span></td>
                                    <td class="column-compact">
                                        <span><?php echo e($fmt($medicalRecord->oldGlasses->os_axis ?? null)); ?></span></td>
                                    <td class="column-compact">
                                        <span><?php echo e($fmt($medicalRecord->oldGlasses->os_prism ?? null)); ?></span></td>
                                    <td class="column-compact">
                                        <span><?php echo e($fmt($medicalRecord->oldGlasses->os_add ?? null)); ?></span></td>
                                    <td class="column-compact">
                                        <span><?php echo e($fmt($medicalRecord->oldGlasses->os_mpd ?? null)); ?></span></td>
                                    <td class="column-compact">
                                        <span><?php echo e($fmt($medicalRecord->oldGlasses->os_cc ?? null)); ?></span></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            
            <div class="card mb-3">
                <div class="card-header fw-semibold">Ukuran Resep Dokter</div>
                <div class="card-body">

                    <div class="table-responsive mb-3">
                        <table class="table table-bordered align-middle text-center">
                            <thead>
                                <tr>
                                    <th></th>
                                    <th>SPH</th>
                                    <th>CYL</th>
                                    <th>AXIS</th>
                                    <th>PRISM</th>
                                    <th>ADD</th>
                                    <th>MPD</th>
                                    <th>CC</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <th>
                                        <span class="badge bg-danger fs-6">OD</span>
                                        <div class="text-muted" style="font-size:.72rem">Kanan</div>
                                    </th>
                                    <td class="column-compact">
                                        <span><?php echo e($fmt($medicalRecord->prescription->od_sph ?? null)); ?></span></td>
                                    <td class="column-compact">
                                        <span><?php echo e($fmt($medicalRecord->prescription->od_cyl ?? null)); ?></span></td>
                                    <td class="column-compact">
                                        <span><?php echo e($fmt($medicalRecord->prescription->od_axis ?? null)); ?></span></td>
                                    <td class="column-compact">
                                        <span><?php echo e($fmt($medicalRecord->prescription->od_prism ?? null)); ?></span></td>
                                    <td class="column-compact">
                                        <span><?php echo e($fmt($medicalRecord->prescription->od_add ?? null)); ?></span></td>
                                    <td class="column-compact">
                                        <span><?php echo e($fmt($medicalRecord->prescription->od_mpd ?? null)); ?></span></td>
                                    <td class="column-compact">
                                        <span><?php echo e($fmt($medicalRecord->prescription->od_cc ?? null)); ?></span></td>
                                </tr>
                                <tr>
                                    <th>
                                        <span class="badge bg-info fs-6">OS</span>
                                        <div class="text-muted" style="font-size:.72rem">Kiri</div>
                                    </th>
                                    <td class="column-compact">
                                        <span><?php echo e($fmt($medicalRecord->prescription->os_sph ?? null)); ?></span></td>
                                    <td class="column-compact">
                                        <span><?php echo e($fmt($medicalRecord->prescription->os_cyl ?? null)); ?></span></td>
                                    <td class="column-compact">
                                        <span><?php echo e($fmt($medicalRecord->prescription->os_axis ?? null)); ?></span></td>
                                    <td class="column-compact">
                                        <span><?php echo e($fmt($medicalRecord->prescription->os_prism ?? null)); ?></span></td>
                                    <td class="column-compact">
                                        <span><?php echo e($fmt($medicalRecord->prescription->os_add ?? null)); ?></span></td>
                                    <td class="column-compact">
                                        <span><?php echo e($fmt($medicalRecord->prescription->os_mpd ?? null)); ?></span></td>
                                    <td class="column-compact">
                                        <span><?php echo e($fmt($medicalRecord->prescription->os_cc ?? null)); ?></span></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>

                    <div class="row">
                        
                        <div class="col-md-4">
                            <label class="form-label fw-semibold">
                                Diagnosis <span class="text-danger"></span>
                            </label>
                            <br>
                            <span><?php echo e($medicalRecord->prescription->diagnosis ?? '-'); ?></span>
                        </div>

                        <div class="col-md-4">
                            <label class="form-label fw-semibold">Asal Resep / Dokter</label>
                            <br>
                            <span><?php echo e($medicalRecord->prescription->doctor_name ?? '-'); ?></span>
                        </div>

                        <div class="col-md-4">
                            <label class="form-label fw-semibold">Tanggal Resep</label>
                            <br>
                            <span><?php echo e($medicalRecord->prescription->exam_date ?? '-'); ?></span>
                        </div>

                        <div class="col-md-12 mt-2">
                            <label class="form-label fw-semibold">Keterangan</label>
                            <br>
                            <span><?php echo e($medicalRecord->prescription->notes ?? '-'); ?></span>
                        </div>
                    </div>

                </div>
            </div>

            
            <div class="card mb-3">
                <div class="card-header fw-semibold">Hasil Refraksi</div>
                <div class="card-body">

                    <div class="table-responsive mb-3">
                        <table class="table table-bordered align-middle text-center">
                            <thead>
                                <tr>
                                    <th></th>
                                    <th>SC</th>
                                    <th>SPH</th>
                                    <th>CYL</th>
                                    <th>AXIS</th>
                                    <th>PRISM</th>
                                    <th>ADD</th>
                                    <th>MPD</th>
                                    <th>CC</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <th>
                                        <span class="badge bg-danger fs-6">OD</span>
                                        <div class="text-muted" style="font-size:.72rem">Kanan</div>
                                    </th>
                                    <td class="column-compact">
                                        <span><?php echo e($fmt($medicalRecord->refraction->od_sc ?? null)); ?></span></td>
                                    <td class="column-compact">
                                        <span><?php echo e($fmt($medicalRecord->refraction->od_sph ?? null)); ?></span></td>
                                    <td class="column-compact">
                                        <span><?php echo e($fmt($medicalRecord->refraction->od_cyl ?? null)); ?></span></td>
                                    <td class="column-compact">
                                        <span><?php echo e($fmt($medicalRecord->refraction->od_axis ?? null)); ?></span></td>
                                    <td class="column-compact">
                                        <span><?php echo e($fmt($medicalRecord->refraction->od_prism ?? null)); ?></span></td>
                                    <td class="column-compact">
                                        <span><?php echo e($fmt($medicalRecord->refraction->od_add ?? null)); ?></span></td>
                                    <td class="column-compact">
                                        <span><?php echo e($fmt($medicalRecord->refraction->od_mpd ?? null)); ?></span></td>
                                    <td class="column-compact">
                                        <span><?php echo e($fmt($medicalRecord->refraction->od_cc ?? null)); ?></span></td>
                                </tr>
                                <tr>
                                    <th>
                                        <span class="badge bg-info fs-6">OS</span>
                                        <div class="text-muted" style="font-size:.72rem">Kiri</div>
                                    </th>
                                    <td class="column-compact">
                                        <span><?php echo e($fmt($medicalRecord->refraction->os_sc ?? null)); ?></span></td>
                                    <td class="column-compact">
                                        <span><?php echo e($fmt($medicalRecord->refraction->os_sph ?? null)); ?></span></td>
                                    <td class="column-compact">
                                        <span><?php echo e($fmt($medicalRecord->refraction->os_cyl ?? null)); ?></span></td>
                                    <td class="column-compact">
                                        <span><?php echo e($fmt($medicalRecord->refraction->os_axis ?? null)); ?></span></td>
                                    <td class="column-compact">
                                        <span><?php echo e($fmt($medicalRecord->refraction->os_prism ?? null)); ?></span></td>
                                    <td class="column-compact">
                                        <span><?php echo e($fmt($medicalRecord->refraction->os_add ?? null)); ?></span></td>
                                    <td class="column-compact">
                                        <span><?php echo e($fmt($medicalRecord->refraction->os_mpd ?? null)); ?></span></td>
                                    <td class="column-compact">
                                        <span><?php echo e($fmt($medicalRecord->refraction->os_cc ?? null)); ?></span></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>

                    <div class="row">
                        
                        <div class="col-md-4">
                            <label class="form-label fw-semibold">
                                Diagnosis <span class="text-danger"></span>
                            </label>
                            <br>
                            <span><?php echo e($medicalRecord->refraction->diagnosis ?? '-'); ?></span>
                        </div>

                        <div class="col-md-4">
                            <label class="form-label fw-semibold">Asal Resep / Dokter</label>
                            <br>
                            <span><?php echo e($medicalRecord->refraction->doctor_name ?? '-'); ?></span>
                        </div>

                        <div class="col-md-4">
                            <label class="form-label fw-semibold">Tanggal Resep</label>
                            <br>
                            <span><?php echo e($medicalRecord->refraction->exam_date ?? '-'); ?></span>
                        </div>

                        <div class="col-md-12 mt-2">
                            <label class="form-label fw-semibold">Keterangan</label>
                            <br>
                            <span><?php echo e($medicalRecord->refraction->notes ?? '-'); ?></span>
                        </div>
                    </div>

                </div>
            </div>

            
            <?php if($medicalRecord->transaction): ?>
                <div class="card mb-3">
                    <div class="card-header p-3"><i class="bi bi-receipt text-success me-2"></i>Transaksi Terkait</div>
                    <div class="card-body p-3">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <div class="fw-bold"><?php echo e($medicalRecord->transaction->no_transaksi); ?></div>
                                <div class="text-muted small"><?php echo e($medicalRecord->transaction->created_at->format('d M Y H:i')); ?>

                                </div>
                            </div>
                            <div class="text-end">
                                <div class="fw-bold text-primary fs-5">
                                    Rp <?php echo e(number_format($medicalRecord->transaction->total_bayar, 0, ',', '.')); ?>

                                </div>
                                <span class="badge badge-<?php echo e($medicalRecord->transaction->status); ?>">
                                    <?php echo e(ucfirst($medicalRecord->transaction->status)); ?>

                                </span>
                            </div>
                            <a href="<?php echo e(route('transactions.show', $medicalRecord->transaction)); ?>"
                                class="btn btn-sm btn-outline-primary">
                                <i class="bi bi-eye me-1"></i>Lihat Struk
                            </a>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <div class="d-flex gap-2">
                <a href="<?php echo e(route('patients.show', $medicalRecord->patient)); ?>" class="btn btn-outline-secondary">
                    <i class="bi bi-person me-1"></i>Profil Pasien
                </a>
                <a href="<?php echo e(route('medical-records.index')); ?>" class="btn btn-outline-secondary">
                    <i class="bi bi-arrow-left me-1"></i>Kembali
                </a>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /DATA/darrendb/admin.optikperkasa.com/resources/views/admin/medical-records/show.blade.php ENDPATH**/ ?>