<?php $__env->startSection('title', 'Halaman Tidak Ditemukan'); ?>
<?php $__env->startSection('code', 'Error 404'); ?>
<?php $__env->startSection('icon'); ?>
    <i class="bi bi-search"></i>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('message'); ?>
    Maaf, halaman yang Anda cari tidak dapat ditemukan atau telah dipindahkan. Pastikan alamat URL sudah benar.
<?php $__env->stopSection(); ?>

<?php echo $__env->make('errors.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /DATA/darrendb/admin.optikperkasa.com/resources/views/errors/404.blade.php ENDPATH**/ ?>