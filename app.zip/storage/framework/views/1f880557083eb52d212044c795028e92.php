<?php
    $copies = $copies ?? 1;
?>
<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <title>Bon Pesanan - <?php echo e($transaction->no_transaksi); ?></title>
    <style>
        @page {
            size: 80mm auto;
            margin: 0;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Courier New', Courier, monospace;
            font-size: 8pt;
            color: #000;
            background: #fff;
            width: 80mm;
            -webkit-print-color-adjust: exact;
            print-color-adjust: exact;
        }

        .print-container {
            width: 80mm;
            padding: 3mm 4mm 6mm;
            background: #fff;
        }

        /* ===== HEADER ===== */
        .header {
            text-align: center;
            margin-bottom: 3mm;
            border-bottom: 1px dashed #000;
            padding-bottom: 3mm;
        }

        .header .brand {
            font-size: 16pt;
            font-weight: 900;
            font-family: Arial, Helvetica, sans-serif;
            letter-spacing: 1px;
            line-height: 1;
        }

        .header .brand .optik {
            font-size: 10pt;
            font-weight: 400;
            display: block;
            letter-spacing: 0;
        }

        .header .tagline {
            font-family: 'Georgia', serif;
            font-style: italic;
            font-size: 7pt;
            margin-top: 0.5mm;
        }

        .header .address {
            font-size: 6.5pt;
            margin-top: 1.5mm;
            line-height: 1.4;
        }

        /* ===== DATA ROWS ===== */
        .info-section {
            margin-bottom: 3mm;
            border-bottom: 1px dashed #000;
            padding-bottom: 3mm;
        }

        .info-row {
            display: flex;
            line-height: 1.6;
        }

        .info-label {
            width: 24mm;
            flex-shrink: 0;
        }

        .info-sep {
            width: 3mm;
            text-align: center;
            flex-shrink: 0;
        }

        .info-val {
            flex: 1;
        }

        /* ===== PRODUK ===== */
        .product-section {
            margin-bottom: 3mm;
            border-bottom: 1px dashed #000;
            padding-bottom: 3mm;
        }

        /* ===== HARGA TABLE ===== */
        .price-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 3mm;
            border-bottom: 1px dashed #000;
            padding-bottom: 2mm;
        }

        .price-table td {
            padding: 1pt 0;
            vertical-align: top;
        }

        .price-table .lbl {
            width: auto;
        }

        .price-table .amt {
            text-align: right;
            width: 22mm;
            font-weight: 700;
        }

        .price-table .total-row td {
            border-top: 1px solid #000;
            font-weight: 900;
            padding-top: 2pt;
        }

        /* ===== REFRAKSI ===== */
        .ref-section {
            margin-bottom: 3mm;
            border-bottom: 1px dashed #000;
            padding-bottom: 3mm;
        }

        .ref-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 7.5pt;
        }

        .ref-table th {
            text-align: center;
            font-weight: 700;
            padding: 1pt 2pt;
            border-bottom: 1px solid #000;
        }

        .ref-table th:first-child {
            text-align: left;
            width: 10mm;
        }

        .ref-table td {
            text-align: center;
            padding: 2pt 2pt;
        }

        .ref-table td:first-child {
            text-align: left;
            font-weight: 700;
        }

        /* ===== FOOTER ===== */
        .thanks {
            text-align: center;
            font-family: Arial, Helvetica, sans-serif;
            font-size: 14pt;
            font-weight: 900;
            margin: 4mm 0 3mm;
            letter-spacing: 1px;
        }

        .notes {
            font-size: 6pt;
            line-height: 1.5;
            color: #333;
        }

        .notes b {
            font-weight: 700;
            color: #000;
        }

        .notes ol {
            margin: 0;
            padding-left: 3mm;
        }

        .notes ol li {
            margin-bottom: 1pt;
        }

        .copy-indicator {
            text-align: right;
            font-size: 6pt;
            font-style: italic;
            margin-bottom: 2mm;
            color: #666;
        }

        @media screen {
            body {
                background: #f0f0f0;
                padding: 20px;
            }
            .print-container {
                margin: 0 auto 20px;
                box-shadow: 0 0 10px rgba(0,0,0,0.1);
            }
        }
    </style>
</head>

<body onload="window.print()">
    <?php for($k = 0; $k < $copies; $k++): ?>
        <div class="print-container">
            <div class="copy-indicator">
                <?php if($copies > 1): ?>
                    Rangkap ke-<?php echo e($k + 1); ?>

                <?php endif; ?>
            </div>

            
            <div class="header">
                <div class="brand">
                    <span class="optik">OPTIK</span>
                    PERKASA
                </div>
                <div class="tagline">Solusi Penglihatan Anda</div>
                <div class="address">
                    Jl KH Agus Salim No 42 Bekasi<br>
                    Hp / WA : 0621-80000-590
                </div>
            </div>

            
            <div class="info-section">
                <div class="info-row">
                    <span class="info-label">No Pesanan</span>
                    <span class="info-sep">:</span>
                    <span class="info-val"><?php echo e($transaction->no_transaksi); ?></span>
                </div>
                <div class="info-row">
                    <span class="info-label">Tanggal</span>
                    <span class="info-sep">:</span><br>
                    <span class="info-val">
                        <?php echo e($transaction->created_at->format('d/m/y')); ?>

                        <?php if($transaction->tgl_selesai_janji): ?>
                            &nbsp;&nbsp;&nbsp;Selesai :
                            <?php echo e(\Carbon\Carbon::parse($transaction->tgl_selesai_janji)->format('d/m/y')); ?>

                        <?php endif; ?>
                    </span>
                </div>
                <div class="info-row">
                    <span class="info-label">Pelanggan</span>
                    <span class="info-sep">:</span>
                    <span class="info-val"><?php echo e($transaction->patient->nama ?? ($transaction->nama_pasien ?? 'UMUM')); ?></span>
                </div>
                <div class="info-row">
                    <span class="info-label">No Hp</span>
                    <span class="info-sep">:</span>
                    <span class="info-val"><?php echo e($transaction->patient->no_hp ?? ($transaction->telp_pasien ?? '-')); ?></span>
                </div>
                <div class="info-row">
                    <span class="info-label">No Bpjs</span>
                    <span class="info-sep">:</span>
                    <span class="info-val"><?php echo e($transaction->no_bpjs ?: '-'); ?></span>
                </div>
                <div class="info-row">
                    <span class="info-label">Resep</span>
                    <span class="info-sep">:</span>
                    <span class="info-val"><?php echo e($transaction->asal_resep ?? '-'); ?></span>
                </div>
            </div>

            
            <div class="product-section">
                <?php
                    $items = $transaction->items;
                ?>
                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="info-row">
                        <span class="info-label">
                            <?php if($item->product && $item->product->category): ?>
                                <?php echo e($item->product->category->name); ?>

                            <?php else: ?>
                                <?php echo e(stripos($item->nama_produk, 'Lensa') !== false ? 'Lensa' : (stripos($item->nama_produk, 'Frame') !== false ? 'Frame' : 'Item')); ?>

                            <?php endif; ?>
                        </span>
                        <span class="info-sep">:</span>
                        <span class="info-val"><?php echo e($item->nama_produk); ?></span>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            
            <?php
                $harga = $transaction->harga_jual ?? $transaction->total_harga ?? 0;
                $potongan = $transaction->potongan ?? $transaction->diskon_nominal ?? 0;
                $dp = $transaction->dp ?? $transaction->bayar ?? 0;
                $sisa = max(0, $harga - $potongan - $dp);
            ?>
            <table class="price-table">
                <tr>
                    <td class="lbl">Harga Jual</td>
                    <td class="amt"><?php echo e(number_format($harga, 0, ',', '.')); ?></td>
                </tr>
                <?php if($potongan > 0): ?>
                    <tr>
                        <td class="lbl">Potongan BPJS</td>
                        <td class="amt"><?php echo e(number_format($potongan, 0, ',', '.')); ?></td>
                    </tr>
                <?php endif; ?>
                <tr>
                    <td class="lbl">Uang Muka</td>
                    <td class="amt"><?php echo e(number_format($dp, 0, ',', '.')); ?></td>
                </tr>
                <tr class="total-row">
                    <td class="lbl">Sisa</td>
                    <td class="amt"><?php echo e(number_format($sisa, 0, ',', '.')); ?></td>
                </tr>
            </table>

            
            <div class="ref-section">
                <table class="ref-table">
                    <thead>
                        <tr>
                            <th></th>
                            <th>Sph</th>
                            <th>Cyl</th>
                            <th>Axis</th>
                            <th>Prism</th>
                            <th>Add</th>
                            <th>Mpd</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>OD</td>
                            <td><?php echo e($transaction->od_sph ?: '-'); ?></td>
                            <td><?php echo e($transaction->od_cyl ?: '-'); ?></td>
                            <td><?php echo e($transaction->od_axis ?: '-'); ?></td>
                            <td><?php echo e($transaction->od_prism ?: '-'); ?></td>
                            <td><?php echo e($transaction->od_add ?: '-'); ?></td>
                            <td><?php echo e($transaction->od_pd ?? ($transaction->od_mpd ?? '-')); ?></td>
                        </tr>
                        <tr>
                            <td>OS</td>
                            <td><?php echo e($transaction->os_sph ?: '-'); ?></td>
                            <td><?php echo e($transaction->os_cyl ?: '-'); ?></td>
                            <td><?php echo e($transaction->os_axis ?: '-'); ?></td>
                            <td><?php echo e($transaction->os_prism ?: '-'); ?></td>
                            <td><?php echo e($transaction->os_add ?: '-'); ?></td>
                            <td><?php echo e($transaction->os_pd ?? ($transaction->os_mpd ?? '-')); ?></td>
                        </tr>
                    </tbody>
                </table>
            </div>

            
            <div class="thanks">TERIMA KASIH</div>

            
            <div class="notes">
                <b>Note :</b>
                <ol>
                    <li>Barang yg sudah dibeli/dipesan tidak dapat dikembalikan atau dibatalkan</li>
                    <li>Barang yg dibeli/dipesan jika tidak diambil dalam rentang 2 bulan tidak lagi menjadi tanggung jawab toko</li>
                    <li>Pemasangan lensa pada frame milik Pelanggan, Segala resiko kerusakan (cacat, patah dll) pada kacamata saat pemasangan lensa Menjadi tanggung jawab pelanggan dan diluar tanggung jawab optik</li>
                </ol>
            </div>
        </div>
        <?php if($k < $copies - 1): ?>
            <div style="page-break-after: always; height:1px;"></div>
        <?php endif; ?>
    <?php endfor; ?>
</body>

</html><?php /**PATH C:\dev\optik-master\resources\views/admin/transactions/print/bon.blade.php ENDPATH**/ ?>