<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('page-title', 'Dashboard'); ?>

<?php $__env->startPush('styles'); ?>
    <style>
        .grafik-bar-wrap {
            height: 100px;
            display: flex;
            align-items: flex-end;
            gap: 6px;
        }

        .grafik-bar {
            flex: 1;
            background: #1e2a5e;
            opacity: .7;
            border-radius: 4px 4px 0 0;
            min-height: 4px;
            transition: opacity .2s;
        }

        .grafik-bar:hover {
            opacity: 1;
        }

        .grafik-label {
            font-size: .7rem;
            color: #6c757d;
            text-align: center;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

    
    <div class="row g-3 mb-4">
        <div class="col-6 col-md-4">
            <div class="card stat-card border-primary p-3">
                <div class="d-flex align-items-start justify-content-between">
                    <div>
                        <div class="stat-label">Total Pasien</div>
                        <div class="stat-val text-primary"><?php echo e(number_format($totalPasien)); ?></div>
                    </div>
                    <div class="stat-icon bg-primary bg-opacity-10 text-primary">
                        <i class="bi bi-people-fill"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-6 col-md-4">
            <div class="card stat-card border-success p-3">
                <div class="d-flex align-items-start justify-content-between">
                    <div>
                        <div class="stat-label">Omzet Hari Ini</div>
                        <div class="stat-val text-success" style="font-size:1.15rem">
                            Rp <?php echo e(number_format($omzetHari, 0, ',', '.')); ?>

                        </div>
                    </div>
                    <div class="stat-icon bg-success bg-opacity-10 text-success">
                        <i class="bi bi-cash-coin"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-6 col-md-4">
            <div class="card stat-card border-info p-3">
                <div class="d-flex align-items-start justify-content-between">
                    <div>
                        <div class="stat-label">Transaksi Hari Ini</div>
                        <div class="stat-val text-info"><?php echo e($transaksiHari); ?></div>
                    </div>
                    <div class="stat-icon bg-info bg-opacity-10 text-info">
                        <i class="bi bi-receipt"></i>
                    </div>
                </div>
            </div>
        </div>
        <!-- <div class="col-6 col-md-3">
                    <div class="card stat-card border-warning p-3">
                        <div class="d-flex align-items-start justify-content-between">
                            <div>
                                <div class="stat-label">Produk Aktif</div>
                                <div class="stat-val text-warning"><?php echo e(number_format($totalProduk)); ?></div>
                            </div>
                            <div class="stat-icon bg-warning bg-opacity-10 text-warning">
                                <i class="bi bi-box-seam-fill"></i>
                            </div>
                        </div>
                    </div>
                </div> -->
    </div>

    <div class="row g-3 mb-3">
        
        <div class="col-md-12">
            <div class="card p-3 h-100">
                <div class="card-header px-0 pt-0 mb-3">
                    <i class="bi bi-bar-chart-fill text-primary me-2"></i>Omzet 7 Hari Terakhir
                </div>
                <?php $maxOmzet = $grafikOmzet->max() ?: 1; ?>
                <div class="grafik-bar-wrap">
                    <?php $__currentLoopData = $grafikOmzet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div style="flex:1; display:flex; flex-direction:column; align-items:center; gap:4px;">
                            <small class="text-muted" style="font-size:.65rem">
                                Rp<?php echo e(number_format($val / 1000, 0)); ?>k
                            </small>
                            <div class="grafik-bar w-100" style="height:<?php echo e(max(4, ($val / $maxOmzet) * 90)); ?>px"
                                title="Rp <?php echo e(number_format($val, 0, ',', '.')); ?>"></div>
                            <div class="grafik-label"><?php echo e($label); ?></div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>

        
        <!-- <div class="col-md-4">
                    <div class="card p-3 h-100">
                        <div class="card-header px-0 pt-0 mb-3">
                            <i class="bi bi-exclamation-triangle-fill text-danger me-2"></i>Stok Menipis
                        </div>
                        <?php $__empty_1 = true; $__currentLoopData = $stokMenipis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="d-flex justify-content-between align-items-center py-2 border-bottom">
                                <div>
                                    <div class="fw-semibold" style="font-size:.82rem"><?php echo e($p->nama); ?></div>
                                    <div class="text-muted" style="font-size:.72rem"><?php echo e($p->category->nama); ?></div>
                                </div>
                                <span class="badge <?php echo e($p->stok == 0 ? 'bg-danger' : 'bg-warning text-dark'); ?>">
                                    <?php echo e($p->stok); ?> <?php echo e($p->satuan); ?>

                                </span>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="text-center text-muted py-3">
                                <i class="bi bi-check-circle fs-3 text-success"></i>
                                <div class="mt-1 small">Semua stok aman</div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <div class="row g-3">
                
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-header p-3 d-flex justify-content-between align-items-center">
                            <div><i class="bi bi-clock-history text-primary me-2"></i>Transaksi Terbaru</div>
                            <a href="<?php echo e(route('transactions.index')); ?>" class="btn btn-outline-primary btn-sm">Lihat semua</a>
                        </div>
                        <div class="table-responsive">
                            <table class="table mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th class="ps-3">No. Transaksi</th>
                                        <th>Pasien</th>
                                        <th>Kasir</th>
                                        <th>Total</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $transaksiTerbaru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td class="ps-3">
                                                <a href="<?php echo e(route('transactions.show', $trx)); ?>"
                                                    class="text-decoration-none fw-semibold">
                                                    <?php echo e($trx->no_transaksi); ?>

                                                </a>
                                            </td>
                                            <td><?php echo e($trx->patient->nama ?? '-'); ?></td>
                                            <td><?php echo e($trx->kasir->name ?? '-'); ?></td>
                                            <td>Rp <?php echo e(number_format($trx->total_bayar, 0, ',', '.')); ?></td>
                                            <td>
                                                <span class="badge badge-<?php echo e($trx->status); ?>"><?php echo e(ucfirst($trx->status)); ?></span>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td colspan="5" class="text-center text-muted py-4">Belum ada transaksi hari ini</td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div> -->

        
        <!-- <div class="col-md-5">
                <div class="card">
                    <div class="card-header p-3 d-flex justify-content-between align-items-center">
                        <div><i class="bi bi-bag-check text-success me-2"></i>Pesanan Mau Diambil (Hari Ini & Terlewat)</div>
                        <a href="<?php echo e(route('pickup.index')); ?>" class="btn btn-outline-success btn-sm">Lihat semua</a>
                    </div>
                    <div class="table-responsive">
                        <table class="table mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th class="ps-3">No. Transaksi</th>
                                    <th>Pasien</th>
                                    <th>Tgl. Pengambilan</th>
                                    <th>Produk</th>
                                    <th>Sisa Tagihan</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $pesananDiambil; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td class="ps-3">
                                            <a href="<?php echo e(route('transactions.show', $trx)); ?>"
                                                class="text-decoration-none fw-semibold">
                                                <?php echo e($trx->no_transaksi); ?>

                                            </a>
                                        </td>
                                        <td><?php echo e($trx->patient->nama ?? ($trx->nama_pasien ?? 'Umum')); ?></td>
                                        <td>
                                            <?php if($trx->tgl_selesai_janji): ?>
                                                <?php
                                                    $isPast = \Carbon\Carbon::parse($trx->tgl_selesai_janji)->isPast();
                                                    $isToday = \Carbon\Carbon::parse($trx->tgl_selesai_janji)->isToday();
                                                ?>
                                                <span
                                                    class="<?php echo e(($isPast && !$isToday) ? 'text-danger fw-bold' : 'text-success fw-bold'); ?>">
                                                    <?php echo e(\Carbon\Carbon::parse($trx->tgl_selesai_janji)->format('d/m/Y')); ?>

                                                </span>
                                            <?php else: ?>
                                                -
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <ul class="mb-0 ps-3" style="font-size: 0.8rem">
                                                <?php $__currentLoopData = $trx->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li><?php echo e($item->qty); ?>x <?php echo e($item->nama_produk); ?></li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        </td>
                                        <td>
                                            <?php
                                                $harga = $trx->harga_jual ?? $trx->total_harga ?? 0;
                                                $dp = $trx->dp ?? $trx->bayar ?? 0;
                                                $potongan = $trx->potongan ?? $trx->diskon_nominal ?? 0;
                                                $sisa = max(0, $harga - $potongan - $dp);
                                            ?>
                                            <?php if($sisa > 0): ?>
                                                <span class="text-danger fw-semibold">Rp <?php echo e(number_format($sisa, 0, ',', '.')); ?></span>
                                            <?php else: ?>
                                                <span class="text-success"><i class="bi bi-check2-all"></i> Lunas</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="5" class="text-center text-muted py-4">Tidak ada pesanan yang harus diambil
                                            hari ini</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div> -->
    </div>

    <div class="row g-3 mt-1">
        <div class="col-12">
            <div class="card">
                <div class="card-header p-3 d-flex justify-content-between align-items-center">
                    <div><i class="bi bi-bag-check text-success me-2"></i>Daftar Tunggu Pengambilan Kacamata</div>
                    <a href="<?php echo e(route('pickup.index')); ?>" class="btn btn-outline-success btn-sm">Lihat semua</a>
                </div>
                <div class="table-responsive">
                    <table class="table mb-0">
                        <thead class="table-light">
                            <tr>
                                <th class="ps-3">No. Transaksi</th>
                                <th>Pasien</th>
                                <th>Tanggal Janji</th>
                                <th>Produk</th>
                                <th>Sisa Tagihan</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $pesananDiambil; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td class="ps-3">
                                        <a href="<?php echo e(route('transactions.show', $trx)); ?>"
                                            class="text-decoration-none fw-semibold">
                                            <?php echo e($trx->no_transaksi); ?>

                                        </a>
                                    </td>
                                    <td><?php echo e($trx->patient->nama ?? ($trx->nama_pasien ?? 'Umum')); ?></td>
                                    <td><?php echo e($trx->tgl_selesai_janji ? \Carbon\Carbon::parse($trx->tgl_selesai_janji)->format('d/m/Y') : '-'); ?></td>
                                        <!-- <?php if($trx->tgl_selesai_janji): ?>
                                            <?php
                                                $dt = \Carbon\Carbon::parse($trx->tgl_selesai_janji);
                                                $isPast = $dt->isPast() && !$dt->isToday();
                                                $isToday = $dt->isToday();
                                                $isTomorrow = $dt->isTomorrow();
                                            ?>
                                            <span
                                                class="<?php echo e($isPast ? 'text-danger fw-bold' : ($isToday ? 'text-warning fw-bold' : 'text-primary')); ?>">
                                                <?php echo e($dt->format('d/m/Y')); ?>

                                                <?php if($isPast): ?> <span class="badge bg-danger small" style="font-size:0.6rem">OVERDUE</span> <?php endif; ?>
                                                <?php if($isToday): ?> <span class="badge bg-warning text-dark small" style="font-size:0.6rem">HARI INI</span> <?php endif; ?>
                                                <?php if($isTomorrow): ?> <span class="badge bg-primary small" style="font-size:0.6rem">BESOK</span> <?php endif; ?>
                                            </span>
                                        <?php else: ?>
                                            <span class="text-muted">-</span>
                                        <?php endif; ?> -->
                                    <!-- </td> -->
                                    <td>
                                        <ul class="mb-0 ps-3" style="font-size: 0.8rem">
                                            <?php $__currentLoopData = $trx->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><?php echo e($item->qty); ?>x <?php echo e($item->nama_produk); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </td>
                                    <td>
                                        <?php
                                            $harga = $trx->harga_jual ?? $trx->total_harga ?? 0;
                                            $dp = $trx->dp ?? $trx->bayar ?? 0;
                                            $potongan = $trx->potongan ?? $trx->diskon_nominal ?? 0;
                                            $sisa = max(0, $harga - $potongan - $dp);
                                        ?>
                                        <?php if($sisa > 0): ?>
                                            <span class="text-danger fw-semibold">Rp <?php echo e(number_format($sisa, 0, ',', '.')); ?></span>
                                        <?php else: ?>
                                            <span class="text-success"><i class="bi bi-check2-all"></i> Lunas</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="5" class="text-center text-muted py-4">Semua pesanan sudah diambil</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\dev\optik-master\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>