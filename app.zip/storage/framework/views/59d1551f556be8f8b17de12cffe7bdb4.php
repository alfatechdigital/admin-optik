<?php if($paginator->hasPages()): ?>
    <nav aria-label="Pagination" class="d-flex flex-column flex-sm-row align-items-center justify-content-between gap-3">
        
        <div class="text-muted small">
            Menampilkan
            <span class="fw-semibold text-dark"><?php echo e($paginator->firstItem()); ?></span>
            -
            <span class="fw-semibold text-dark"><?php echo e($paginator->lastItem()); ?></span>
            dari
            <span class="fw-semibold text-dark"><?php echo e($paginator->total()); ?></span>
            data
        </div>

        
        <ul class="pagination pagination-sm mb-0 gap-1">
            
            <?php if($paginator->onFirstPage()): ?>
                <li class="page-item disabled">
                    <span class="page-link border-0 rounded-3 bg-transparent text-muted px-3">
                        <i class="bi bi-chevron-left"></i>
                    </span>
                </li>
            <?php else: ?>
                <li class="page-item">
                    <a class="page-link border-0 rounded-3 bg-white text-secondary shadow-sm px-3 pagination-hover"
                       href="<?php echo e($paginator->previousPageUrl()); ?>" rel="prev">
                        <i class="bi bi-chevron-left"></i>
                    </a>
                </li>
            <?php endif; ?>

            
            <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <?php if(is_string($element)): ?>
                    <li class="page-item disabled">
                        <span class="page-link border-0 rounded-3 bg-transparent text-muted px-2"><?php echo e($element); ?></span>
                    </li>
                <?php endif; ?>

                
                <?php if(is_array($element)): ?>
                    <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($page == $paginator->currentPage()): ?>
                            <li class="page-item active">
                                <span class="page-link border-0 rounded-3 text-white fw-semibold px-3 shadow-sm"
                                      style="background: linear-gradient(135deg, #1e2a5e 0%, #3b5998 100%);">
                                    <?php echo e($page); ?>

                                </span>
                            </li>
                        <?php else: ?>
                            <li class="page-item">
                                <a class="page-link border-0 rounded-3 bg-white text-secondary shadow-sm px-3 pagination-hover"
                                   href="<?php echo e($url); ?>">
                                    <?php echo e($page); ?>

                                </a>
                            </li>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            
            <?php if($paginator->hasMorePages()): ?>
                <li class="page-item">
                    <a class="page-link border-0 rounded-3 bg-white text-secondary shadow-sm px-3 pagination-hover"
                       href="<?php echo e($paginator->nextPageUrl()); ?>" rel="next">
                        <i class="bi bi-chevron-right"></i>
                    </a>
                </li>
            <?php else: ?>
                <li class="page-item disabled">
                    <span class="page-link border-0 rounded-3 bg-transparent text-muted px-3">
                        <i class="bi bi-chevron-right"></i>
                    </span>
                </li>
            <?php endif; ?>
        </ul>
    </nav>

    <style>
        .pagination-hover {
            transition: all 0.2s ease;
        }
        .pagination-hover:hover {
            background-color: #eef2ff !important;
            color: #1e2a5e !important;
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(30, 42, 94, 0.15) !important;
        }
        .pagination .page-item.active .page-link {
            box-shadow: 0 4px 12px rgba(30, 42, 94, 0.3) !important;
        }
    </style>
<?php endif; ?>
<?php /**PATH /DATA/darrendb/admin.optikperkasa.com/resources/views/vendor/pagination/custom-bootstrap.blade.php ENDPATH**/ ?>