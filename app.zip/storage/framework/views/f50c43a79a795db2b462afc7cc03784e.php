
<?php $__env->startSection('title', 'Edit Rekam Medis'); ?>
<?php $__env->startSection('page-title', 'Edit Rekam Medis'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center">
        <div class="col-xl-10">
            <form method="POST" action="<?php echo e(route('medical-records.update', $medicalRecord)); ?>" id="mrForm">
                <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>

                <div class="card mb-3">
                    <div class="card-header p-3">
                        <i class="bi bi-pencil text-warning me-2"></i>Edit Rekam Medis — <?php echo e($medicalRecord->patient->nama); ?>

                    </div>
                    <div class="card-body p-4">
                        <div class="row g-3">
                            <div class="col-md-5">
                                <label class="form-label fw-semibold">
                                    Pasien <span class="text-danger">*</span>
                                </label>

                                
                                <input type="hidden" name="patient_id" id="patient_id"
                                    value="<?php echo e(old('patient_id', $selectedPatient?->id)); ?>">

                                
                                <?php
                                    $displayPatient = old('patient_id')
                                        ? $selectedPatient
                                        : ($medicalRecord->patient ?? null);
                                ?>

                                <input type="text" id="patient_search"
                                    class="form-control <?php $__errorArgs = ['patient_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    placeholder="Cari No RM / Nama pasien..."
                                    value="<?php echo e($displayPatient ? $displayPatient->no_rm . ' — ' . $displayPatient->nama : ''); ?>"
                                    autocomplete="off" required>

                                
                                <div id="patient_result" class="list-group position-absolute w-100 shadow"
                                    style="z-index:1000;"></div>

                                <?php $__errorArgs = ['patient_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label fw-semibold">
                                    Dokter / Pemeriksa <span class="text-danger">*</span>
                                </label>

                                <input type="text" name="nama_dokter" id="doctor_search"
                                    class="form-control <?php $__errorArgs = ['nama_dokter'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    value="<?php echo e(old('nama_dokter', $medicalRecord->refraction->doctor_name ?? $medicalRecord->prescription->doctor_name ?? '')); ?>"
                                    placeholder="Masukkan nama dokter" autocomplete="off" required>

                                
                                <div id="doctor_result" class="list-group position-absolute w-100 shadow"
                                    style="z-index:1000;"></div>

                                <?php $__errorArgs = ['nama_dokter'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-3">
                                <label class="form-label fw-semibold">Tanggal Kunjungan <span
                                        class="text-danger">*</span></label>
                                <input type="date" name="tanggal_kunjungan" class="form-control" required
                                    value="<?php echo e(old('visit_date', $medicalRecord->visit_date->format('Y-m-d'))); ?>">
                            </div>
                            <div class="col-12">
                                <label class="form-label fw-semibold">Keluhan Utama</label>
                                <input type="text" name="keluhan" class="form-control"
                                    value="<?php echo e(old('complaint', $medicalRecord->complaint)); ?>">
                            </div>
                        </div>
                    </div>
                </div>

                
                <div class="card mb-3">
                    <div class="card-header p-3"><i class="bi bi-eyeglasses text-primary me-2"></i>Ukuran Kacamata Lama
                    </div>
                    <div class="card-body p-4">
                        <div class="table-responsive">
                            <table class="table table-bordered align-middle">
                                <thead class="table-light text-center">
                                    <tr>
                                        <th>Mata</th>
                                        <th>SPH</th>
                                        <th>CYL</th>
                                        <th>AXIS</th>
                                        <th>PRISM</th>
                                        <th>ADD</th>
                                        <th>MPD</th>
                                        <th>CC</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = [['od', 'Kanan', 'danger'], ['os', 'Kiri', 'info']]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$eye, $label, $color]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="text-center">
                                                <span class="badge bg-<?php echo e($color); ?> fs-6"><?php echo e(strtoupper($eye)); ?></span>
                                                <div class="text-muted" style="font-size:.72rem"><?php echo e($label); ?></div>
                                            </td>
                                            <?php $__currentLoopData = ['sph', 'cyl', 'axis', 'prism', 'add', 'mpd', 'cc']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <td>
                                                    <input type="text" name="og_<?php echo e($eye); ?>_<?php echo e($field); ?>"
                                                        class="form-control text-center"
                                                        step="<?php echo e(in_array($field, ['axis']) ? 1 : 0.25); ?>"
                                                        value="<?php echo e(old('og_'.$eye.'_'.$field, $medicalRecord->oldGlasses?->{"{$eye}_{$field}"} ?? '')); ?>"
                                                        placeholder="-">
                                                </td>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                
                <div class="card mb-3">
                    <div class="card-header p-3"><i class="bi bi-eyeglasses text-primary me-2"></i>Ukuran Resep Dokter</div>
                    <div class="card-body p-4">
                        <div class="table-responsive">
                            <table class="table table-bordered align-middle">
                                <thead class="table-light text-center">
                                    <tr>
                                        <th>Mata</th>
                                        <th>SPH</th>
                                        <th>CYL</th>
                                        <th>AXIS</th>
                                        <th>PRISM</th>
                                        <th>ADD</th>
                                        <th>MPD</th>
                                        <th>CC</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = [['od', 'Kanan', 'danger'], ['os', 'Kiri', 'info']]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$eye, $label, $color]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="text-center">
                                                <span class="badge bg-<?php echo e($color); ?> fs-6"><?php echo e(strtoupper($eye)); ?></span>
                                                <div class="text-muted" style="font-size:.72rem"><?php echo e($label); ?></div>
                                            </td>
                                            <?php $__currentLoopData = ['sph', 'cyl', 'axis', 'prism', 'add', 'mpd', 'cc']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <td>
                                                    <input type="text" name="presc_<?php echo e($eye); ?>_<?php echo e($field); ?>"
                                                        class="form-control text-center"
                                                        step="<?php echo e(in_array($field, ['axis']) ? 1 : 0.25); ?>"
                                                        value="<?php echo e(old('presc_'.$eye.'_'.$field, $medicalRecord->prescription?->{"{$eye}_{$field}"} ?? '')); ?>"
                                                        placeholder="-">
                                                </td>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="row g-3 mt-1">
                            
                            <div class="col-md-4">
                                <label class="form-label fw-semibold">Diagnosa</label>

                                
                                <input type="text" id="rx_diagnosis_search" name="presc_diagnosis"
                                    class="form-control <?php $__errorArgs = ['presc_diagnosis'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    placeholder="Cari atau ketik Diagnosa..."
                                    value="<?php echo e(old('presc_diagnosis', $medicalRecord->prescription?->diagnosis ?? '')); ?>"
                                    autocomplete="off">

                                
                                <div id="rx_diagnosis_result" class="list-group position-absolute w-100 shadow"
                                    style="z-index:1000;"></div>

                                <?php $__errorArgs = ['presc_diagnosis'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-md-4">
                                <label class="form-label fw-semibold">Tanggal Resep</label>
                                <input type="date" name="presc_exam_date" class="form-control"
                                    value="<?php echo e(old('presc_exam_date', $medicalRecord->prescription?->exam_date)); ?>">
                            </div>

                            <div class="col-12">
                                <label class="form-label fw-semibold">Catatan Dokter</label>
                                <textarea name="presc_notes" class="form-control"
                                    rows="3"><?php echo e(old('presc_notes', $medicalRecord->prescription?->notes)); ?></textarea>
                            </div>
                        </div>
                    </div>
                </div>

                
                <div class="card mb-3">
                    <div class="card-header p-3"><i class="bi bi-eyeglasses text-primary me-2"></i>Hasil Refraksi</div>
                    <div class="card-body p-4">
                        <div class="table-responsive">
                            <table class="table table-bordered align-middle">
                                <thead class="table-light text-center">
                                    <tr>
                                        <th>Mata</th>
                                        <th>SC</th>
                                        <th>SPH</th>
                                        <th>CYL</th>
                                        <th>AXIS</th>
                                        <th>PRISM</th>
                                        <th>ADD</th>
                                        <th>MPD</th>
                                        <th>CC</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = [['od', 'Kanan', 'danger'], ['os', 'Kiri', 'info']]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$eye, $label, $color]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="text-center">
                                                <span class="badge bg-<?php echo e($color); ?> fs-6"><?php echo e(strtoupper($eye)); ?></span>
                                                <div class="text-muted" style="font-size:.72rem"><?php echo e($label); ?></div>
                                            </td>
                                            <?php $__currentLoopData = ['sc', 'sph', 'cyl', 'axis', 'prism', 'add', 'mpd', 'cc']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <td>
                                                    <input type="text" name="ref_<?php echo e($eye); ?>_<?php echo e($field); ?>"
                                                        class="form-control text-center"
                                                        step="<?php echo e(in_array($field, ['axis']) ? 1 : 0.25); ?>"
                                                        value="<?php echo e(old("ref_{$eye}_{$field}", $medicalRecord->refraction?->{$eye . '_' . $field}) ?? ''); ?>"
                                                        placeholder="<?php echo e(empty($value) ? '-' : ''); ?>">
                                                </td>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="row g-3 mt-1">
                            
                            <div class="col-md-4">
                                <label class="form-label fw-semibold">
                                    Diagnosa
                                </label>

                                
                                <input type="text" id="ref_diagnosis_search" name="ref_diagnosis"
                                    class="form-control <?php $__errorArgs = ['ref_diagnosis'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    placeholder="Cari atau ketik Diagnosa..."
                                    value="<?php echo e(old('ref_diagnosis', $medicalRecord->refraction?->diagnosis ?? '')); ?>"
                                    autocomplete="off">

                                
                                <div id="ref_diagnosis_result" class="list-group position-absolute w-100 shadow"
                                    style="z-index:1000;"></div>

                                <?php $__errorArgs = ['ref_diagnosis'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-md-4">
                                <label class="form-label fw-semibold">Tanggal Resep</label>
                                <input type="date" name="ref_exam_date" class="form-control"
                                    value="<?php echo e(old('ref_exam_date', $medicalRecord->refraction?->exam_date)); ?>">
                            </div>

                            <div class="col-12">
                                <label class="form-label fw-semibold">Catatan Dokter</label>
                                <textarea name="ref_notes" class="form-control"
                                    rows="3"><?php echo e(old('ref_notes', $medicalRecord->refraction?->notes)); ?></textarea>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="d-flex gap-2">
                    <button type="submit" class="btn btn-warning px-4">
                        <i class="bi bi-check-lg me-1"></i>Update Rekam Medis
                    </button>
                    <a href="<?php echo e(route('medical-records.show', $medicalRecord)); ?>"
                        class="btn btn-outline-secondary">Batal</a>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
document.getElementById('mrForm').addEventListener('submit', function(e) {
    const patientId = document.getElementById('patient_id').value;
    if (!patientId) {
        e.preventDefault();
        Swal.fire({
            icon: 'warning',
            title: 'Data Belum Lengkap',
            text: 'Pasien wajib dipilih dari hasil pencarian.',
            confirmButtonText: 'Baik, saya perbaiki'
        });
        document.getElementById('patient_search').classList.add('is-invalid');
        document.getElementById('patient_search').focus();
        return false;
    }
    
    const doctorSearch = document.getElementById('doctor_search').value.trim();
    if (!doctorSearch) {
        e.preventDefault();
        Swal.fire({
            icon: 'warning',
            title: 'Data Belum Lengkap',
            text: 'Nama Dokter / Pemeriksa wajib diisi.',
            confirmButtonText: 'Baik, saya perbaiki'
        });
        document.getElementById('doctor_search').classList.add('is-invalid');
        document.getElementById('doctor_search').focus();
        return false;
    }
    
    const visitDate = document.querySelector('input[name="tanggal_kunjungan"]').value;
    if (!visitDate) {
        e.preventDefault();
        Swal.fire({
            icon: 'warning',
            title: 'Data Belum Lengkap',
            text: 'Tanggal Kunjungan wajib diisi.',
            confirmButtonText: 'Baik, saya perbaiki'
        });
        document.querySelector('input[name="tanggal_kunjungan"]').classList.add('is-invalid');
        document.querySelector('input[name="tanggal_kunjungan"]').focus();
        return false;
    }
});
</script>
<?php $__env->stopPush(); ?>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        const input = document.getElementById('ref_diagnosis_search');
        const resultBox = document.getElementById('ref_diagnosis_result');

        let timeout = null;

        input.addEventListener('input', function () {
            const query = this.value;

            clearTimeout(timeout);

            if (query.length < 2) {
                resultBox.innerHTML = '';
                return;
            }

            timeout = setTimeout(() => {
                fetch(`<?php echo e(route('diagnoses.search')); ?>?q=${query}`)
                    .then(res => res.json())
                    .then(data => {
                        resultBox.innerHTML = '';

                        // 🔹 tampilkan hasil dari DB
                        data.forEach(item => {
                            const el = document.createElement('a');
                            el.href = "#";
                            el.className = 'list-group-item list-group-item-action';
                            el.textContent = item.name;

                            el.addEventListener('click', function (e) {
                                e.preventDefault();
                                input.value = item.name;
                                resultBox.innerHTML = '';
                            });

                            resultBox.appendChild(el);
                        });

                        // 🔸 tambahan: opsi input manual
                        if (data.length === 0) {
                            const el = document.createElement('div');
                            el.className = 'list-group-item text-muted';
                            el.textContent = 'Tidak ditemukan, tekan Enter untuk input manual';
                            resultBox.appendChild(el);
                        }
                    });
            }, 300);
        });

        // klik luar → close
        document.addEventListener('click', function (e) {
            if (!input.contains(e.target) && !resultBox.contains(e.target)) {
                resultBox.innerHTML = '';
            }
        });
    });
    // doctor autocomplete
    document.addEventListener('DOMContentLoaded', function () {
        const input = document.getElementById('doctor_search');
        const resultBox = document.getElementById('doctor_result');

        let timeout = null;

        input.addEventListener('keyup', function () {
            const query = this.value;

            clearTimeout(timeout);

            if (query.length < 2) {
                resultBox.innerHTML = '';
                return;
            }

            timeout = setTimeout(() => {
                fetch(`<?php echo e(route('doctors.autocomplete')); ?>?q=${query}`)
                    .then(res => res.json())
                    .then(data => {
                        resultBox.innerHTML = '';

                        data.forEach(item => {
                            const el = document.createElement('a');
                            el.href = "#";
                            el.classList.add('list-group-item', 'list-group-item-action');
                            el.textContent = `${item.name}`;

                            el.addEventListener('click', function (e) {
                                e.preventDefault();
                                input.value = `${item.name}`;
                                resultBox.innerHTML = '';
                            });

                            resultBox.appendChild(el);
                        });
                    });
            }, 300);
        });

        // klik luar -> close dropdown
        document.addEventListener('click', function (e) {
            if (!input.contains(e.target)) {
                resultBox.innerHTML = '';
            }
        });
    });
</script>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\dev\admin-optik\resources\views/admin/medical-records/edit.blade.php ENDPATH**/ ?>