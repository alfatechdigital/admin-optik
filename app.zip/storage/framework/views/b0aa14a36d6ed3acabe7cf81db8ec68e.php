
<?php $__env->startSection('title', 'Edit Pasien'); ?>
<?php $__env->startSection('page-title', 'Edit Data Pasien'); ?>

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
<div class="col-md-8">
<div class="card">
    <div class="card-header p-3">
        <i class="bi bi-pencil text-warning me-2"></i>Edit: <?php echo e($patient->nama); ?>

        <span class="badge bg-secondary ms-2"><?php echo e($patient->no_rm); ?></span>
    </div>
    <div class="card-body p-4">
        <form method="POST" action="<?php echo e(route('patients.update', $patient)); ?>" id="patientForm">
            <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
            <div class="row g-3">
                <div class="col-md-8">
                    <label class="form-label fw-semibold">Nama Lengkap <span class="text-danger">*</span></label>
                    <input type="text" name="nama" class="form-control <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                           value="<?php echo e(old('nama', $patient->nama)); ?>" required>
                    <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-4">
                    <label class="form-label fw-semibold">Jenis Kelamin</label>
                    <select name="jenis_kelamin" class="form-select">
                        <option value="">-- Pilih --</option>
                        <option value="L" <?php echo e(old('jenis_kelamin', $patient->jenis_kelamin) == 'L' ? 'selected' : ''); ?>>Laki-laki</option>
                        <option value="P" <?php echo e(old('jenis_kelamin', $patient->jenis_kelamin) == 'P' ? 'selected' : ''); ?>>Perempuan</option>
                    </select>
                </div>
                <div class="col-12">
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">Tanggal Lahir</label>
                        <input type="date" name="tanggal_lahir" class="form-control <?php $__errorArgs = ['tanggal_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                               value="<?php echo e(old('tanggal_lahir', $patient->tanggal_lahir?->format('Y-m-d'))); ?>">
                        <?php $__errorArgs = ['tanggal_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="col-md-6">
                    <label class="form-label fw-semibold">No. NIK</label>
                    <input type="text" name="nik" class="form-control"
                           value="<?php echo e(old('nik', $patient->nik)); ?>" placeholder="NIK (opsional)">
                </div>
                <div class="col-md-6">
                    <label class="form-label fw-semibold">No. HP</label>
                    <input type="text" name="no_hp" class="form-control"
                           value="<?php echo e(old('no_hp', $patient->no_hp)); ?>" placeholder="08xx-xxxx-xxxx">
                </div>
                <div class="col-md-6">
                    <label class="form-label fw-semibold">No. BPJS</label>
                    <input type="text" name="no_bpjs" class="form-control"
                           value="<?php echo e(old('no_bpjs', $patient->no_bpjs)); ?>" placeholder="Nomor BPJS (opsional)">
                </div>
                <div class="col-md-6">
                    <label class="form-label fw-semibold">Tipe BPJS</label>
                    <select name="tipe_bpjs" class="form-select">
                        <option value="">-- Pilih --</option>
                        <option value="1" <?php echo e(old('tipe_bpjs', $patient->tipe_bpjs) == '1' ? 'selected' : ''); ?>>Kelas 1</option>
                        <option value="2" <?php echo e(old('tipe_bpjs', $patient->tipe_bpjs) == '2' ? 'selected' : ''); ?>>Kelas 2</option>
                        <option value="3" <?php echo e(old('tipe_bpjs', $patient->tipe_bpjs) == '3' ? 'selected' : ''); ?>>Kelas 3</option>
                    </select>
                </div>
                <div class="col-md-6">
                    <label class="form-label fw-semibold">Email</label>
                    <input type="email" name="email" class="form-control"
                           value="<?php echo e(old('email', $patient->email)); ?>">
                </div>
                <div class="col-12">
                    <label class="form-label fw-semibold">Alamat</label>
                    <textarea name="alamat" class="form-control" rows="3"><?php echo e(old('alamat', $patient->alamat)); ?></textarea>
                </div>
                <div class="col-12">
                    <label class="form-label fw-semibold">Riwayat Penyakit</label>
                    <textarea name="riwayat_penyakit" class="form-control" rows="2"
                              placeholder="Diabetes, hipertensi, alergi obat..."><?php echo e(old('riwayat_penyakit', $patient->riwayat_penyakit)); ?></textarea>
                </div>
            </div>
            <hr class="my-4">
            <div class="d-flex gap-2">
                <button type="submit" class="btn btn-warning px-4">
                    <i class="bi bi-check-lg me-1"></i>Update Data Pasien
                </button>
                <a href="<?php echo e(route('patients.show', $patient)); ?>" class="btn btn-outline-secondary">Batal</a>
            </div>
        </form>
    </div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
document.getElementById('patientForm').addEventListener('submit', function (e) {
    const nikEl = document.querySelector('input[name="nik"]');
    const nik = nikEl ? nikEl.value.trim() : '';
    if (nik && !/^\d{16}$/.test(nik)) {
        e.preventDefault();
        Swal.fire({
            icon: 'warning',
            title: 'NIK Tidak Valid',
            text: 'Nomor Induk Kependudukan (NIK) harus terdiri dari 16 digit angka.',
            confirmButtonText: 'Baik, saya perbaiki'
        });
        nikEl.classList.add('is-invalid');
        nikEl.focus();
        return false;
    }
    if (nikEl) nikEl.classList.remove('is-invalid');
    
    const noBpjsEl = document.querySelector('input[name="no_bpjs"]');
    const no_bpjs = noBpjsEl ? noBpjsEl.value.trim() : '';
    if (no_bpjs && !/^\d{13}$/.test(no_bpjs)) {
        e.preventDefault();
        Swal.fire({
            icon: 'warning',
            title: 'No BPJS Tidak Valid',
            text: 'Nomor BPJS harus terdiri dari 13 digit angka.',
            confirmButtonText: 'Baik, saya perbaiki'
        });
        noBpjsEl.classList.add('is-invalid');
        noBpjsEl.focus();
        return false;
    }
    if (noBpjsEl) noBpjsEl.classList.remove('is-invalid');
    
    const telpEl = document.querySelector('input[name="no_hp"]');
    const telp = telpEl ? telpEl.value.trim() : '';
    if (telp && !/^\d{9,15}$/.test(telp)) {
        e.preventDefault();
        Swal.fire({
            icon: 'warning',
            title: 'No Telepon Tidak Valid',
            text: 'Nomor telepon harus berupa angka antara 9 hingga 15 digit.',
            confirmButtonText: 'Baik, saya perbaiki'
        });
        telpEl.classList.add('is-invalid');
        telpEl.focus();
        return false;
    }
    if (telpEl) telpEl.classList.remove('is-invalid');
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\dev\admin-optik\resources\views/admin/patients/edit.blade.php ENDPATH**/ ?>