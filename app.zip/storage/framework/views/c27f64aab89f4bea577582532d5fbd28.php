<?php $__env->startSection('title', 'Produk'); ?>
<?php $__env->startSection('page-title', 'Manajemen Produk'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header p-3 d-flex flex-wrap gap-2 justify-content-between align-items-center">
        <div><i class="bi bi-box-seam text-primary me-2"></i>Daftar Produk</div>
        <div class="d-flex flex-wrap gap-2">
            <form class="d-flex flex-wrap gap-2" method="GET">
                <input type="text" name="search" class="form-control form-control-sm"
                       placeholder="Nama / kode / merek..." value="<?php echo e(request('search')); ?>" style="width:200px">
                <select name="category_id" class="form-select form-select-sm" style="width:150px">
                    <option value="">Semua Kategori</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($cat->id); ?>" <?php echo e(request('category_id') == $cat->id ? 'selected' : ''); ?>>
                        <?php echo e($cat->nama); ?>

                    </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <select name="stok" class="form-select form-select-sm" style="width:130px">
                    <option value="">Semua Stok</option>
                    <option value="menipis" <?php echo e(request('stok')=='menipis' ? 'selected' : ''); ?>>Stok Menipis</option>
                </select>
                <button class="btn btn-sm btn-outline-secondary"><i class="bi bi-search"></i></button>
            </form>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('product.create')): ?>
            <a href="<?php echo e(route('products.create')); ?>" class="btn btn-sm btn-primary">
                <i class="bi bi-plus-lg me-1"></i>Tambah Produk
            </a>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('product.view')): ?>
            <a href="<?php echo e(route('products.export')); ?>" class="btn btn-sm btn-success">
                <i class="bi bi-download me-1"></i>Export Excel
            </a>
            <button class="btn btn-sm btn-info" data-bs-toggle="modal" data-bs-target="#importModal">
                <i class="bi bi-upload me-1"></i>Import Excel
            </button>
            <?php endif; ?>
        </div>
    </div>
    <div class="table-responsive">
        <table class="table mb-0">
            <thead class="table-light">
                <tr>
                    <th class="ps-3">#</th>
                    <th>Kode</th>
                    <th>Nama Produk</th>
                    <th>Kategori</th>
                    <th>Harga Jual</th>
                    <th class="text-center">Stok</th>
                    <th class="text-center">Status</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td class="ps-3 text-muted"><?php echo e($products->firstItem() + $i); ?></td>
                    
                    <td><span class="badge bg-secondary"><?php echo e($p->kode_produk); ?></span></td>
                    <td>
                        <div class="fw-semibold"><?php echo e($p->nama); ?></div>
                        <?php if($p->merek): ?>
                        <small class="text-muted"><?php echo e($p->merek); ?></small>
                        <?php endif; ?>
                    </td>
                    <td><?php echo e($p->category->nama); ?></td>
                    <td class="fw-semibold">Rp <?php echo e(number_format($p->harga_jual, 0, ',', '.')); ?></td>
                    <td class="text-center">
                        <span class="badge <?php echo e($p->stok == 0 ? 'bg-danger' : ($p->stok_menipis ? 'bg-warning text-dark' : 'bg-success')); ?>">
                            <?php echo e($p->stok); ?> <?php echo e($p->satuan); ?>

                        </span>
                    </td>
                    <td class="text-center">
                        <span class="badge <?php echo e($p->is_active ? 'bg-success' : 'bg-secondary'); ?>">
                            <?php echo e($p->is_active ? 'Aktif' : 'Nonaktif'); ?>

                        </span>
                    </td>
                    <td>
                        <div class="d-flex gap-1">
                            <a href="<?php echo e(route('products.show', $p)); ?>" class="btn btn-xs btn-outline-info" title="Detail">
                                <i class="bi bi-eye"></i>
                            </a>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('product.edit')): ?>
                            <a href="<?php echo e(route('products.edit', $p)); ?>" class="btn btn-xs btn-outline-warning" title="Edit">
                                <i class="bi bi-pencil"></i>
                            </a>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('product.delete')): ?>
                            <form method="POST" action="<?php echo e(route('products.destroy', $p)); ?>"
                                  onsubmit="return confirm('Hapus produk <?php echo e($p->nama); ?>?')">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                <button class="btn btn-xs btn-outline-danger" title="Hapus">
                                    <i class="bi bi-trash"></i>
                                </button>
                            </form>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="9" class="text-center text-muted py-5">
                        <i class="bi bi-box-seam fs-1 d-block mb-2 opacity-25"></i>
                        Belum ada produk
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php if($products->hasPages()): ?>
    <div class="card-footer"><?php echo e($products->links()); ?></div>
    <?php endif; ?>
</div>

<?php $__env->startPush('styles'); ?>
<style>.btn-xs { padding: 3px 8px; font-size: .75rem; }</style>
<?php $__env->stopPush(); ?>

<!-- Modal Import -->
<div class="modal fade" id="importModal" tabindex="-1" aria-labelledby="importModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="importModalLabel">Import Data Produk</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="<?php echo e(route('products.import')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="file" class="form-label">Pilih File Excel (.xlsx, .xls, .csv)</label>
                        <input type="file" class="form-control" id="file" name="file" accept=".xlsx,.xls,.csv" required>
                        <div class="form-text">
                            Pastikan file memiliki kolom: Kode Produk, Nama, Deskripsi, Merek, Kategori, Harga Beli, Harga Jual, Stok, Stok Minimum, Satuan, Status
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary">Import</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\dev\optik-master\resources\views/admin/products/index.blade.php ENDPATH**/ ?>